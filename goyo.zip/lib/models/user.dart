class User {
  String _phone;
  String _password;
  String _first_name;
  String _last_name;
  String _user_id;
  String _pro_pic;
  String _email;
  String _user_type;
  User(this._email, this._password);

  User.map(dynamic obj) {
    this._phone = obj["phone"];
    this._password = obj["password"];
    this._user_id=obj["user_id"];
    this._first_name=obj["first_name"];
    this._last_name=obj["_last_name"];
    this._pro_pic=obj["pro_pic"];
    this._email=obj['email'];
    this._user_type=obj['user_type'];
  }

  String get email => _email;
  String get password => _password;

  Map<String, dynamic> toMap() {
    var map = new Map<String, dynamic>();
    map["phone"] = _phone;
    map["user_id"] = _user_id;
    map['first_name']=_first_name;
    map['last_name']=_last_name;
    map['pro_pic']=_pro_pic;
    map['email']=_email;
    map['user_type']=_user_type;
    return map;
  }
}