import 'package:flutter/material.dart';

class Users {
  final String reg_no;
  final String name;
  final String age;
  final String caste;
  final String image;
  final String edu;
  final String star;

  Users(
      {@required this.reg_no,
      @required this.name,
      @required this.age,
      @required this.caste,
      @required this.image,
      @required this.edu,
      @required this.star});
}
