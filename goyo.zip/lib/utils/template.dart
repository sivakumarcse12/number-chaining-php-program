import 'package:flutter/widgets.dart';
 Textbold(String val, double size, Color color) {
  return Text(
    val,
    style: TextStyle(fontFamily: 'PoppinsBold', fontSize: size, color: color),
  );
}

 Textslimbold(String val, double size, Color color) {
  return Text(
    val,
    style:
        TextStyle(fontFamily: 'PoppinsSemiBold', fontSize: size, color: color),
  );
}

Textregular(String val, double size, Color color) {
  return Text(
    val,
    style:
        TextStyle(fontFamily: 'PoppinsRegular', fontSize: size, color: color),
  );
}
