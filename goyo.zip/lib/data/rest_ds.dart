import 'dart:async';
import 'dart:convert';
import 'package:http/http.dart' as http;
import 'package:flutter/material.dart';
import './database_helper.dart';
import './../models/user.dart';

class RestDatasource {
  static final BASE_URL =
      "https://www.go-yogi.org/goyogi_admpanel/site/api/";
  static final REGISTER_URL = BASE_URL + "user_signup";
  static final INDIVIDUAL_REGISTER_URL = BASE_URL + "individual_signup";
  static final AUDIO_URL = BASE_URL + "audio_list";
  static final HISAUDIO_URL=BASE_URL+"played_history";
  static final LOGIN_URL = BASE_URL + "user_login_process";
  static final GET_USER_INFO = BASE_URL + "get_user_info";
  static final IMAGE_UPLOAD =
      BASE_URL + "image_upload_new";
  static final AUDIO_PLAYED=BASE_URL+"update_audio_played_log";    
  static final UPDATE_ACCOUNT = BASE_URL + "update_student";
  static final FORGOT_PASSWORD_URL = BASE_URL + "forgot_password";
  static final CHANGE_PASSWORD =
      BASE_URL + "change_password_user";
  static final Username = "Admin";
  static final Password = "123456";
   String basicAuth =
      'Basic ' + base64Encode(utf8.encode('$Username:$Password'));
  Future<dynamic> registration(email, password, token, school_code,language) async {
    var response = await http.post(Uri.encodeFull(REGISTER_URL), headers: <String, String>{
      "Accept": "application/json",
      "authorization":basicAuth,
      
      

    }, body: {
      "first_name": "Guest",
      "last_name":"Guest",
      "school_code": school_code,
      "email": email,
      "password": password,
      "language":language,
      "Devicetype": "android",
      "Deviceid": "token",
    });
   // print(response.body);
    var extractdata = json.decode(response.body); 
    if (extractdata['status'] == 1) {
      return extractdata;
    } else {
      return extractdata;
    }
  }
Future<dynamic> individual_registration(email, password, token,language) async {
    var response = await http.post(Uri.encodeFull(INDIVIDUAL_REGISTER_URL), headers: <String, String>{
      "Accept": "application/json",
      "authorization":basicAuth,
    }, body: {
      "first_name": "Guest",
      "last_name":"Guest",
      "email": email,
      "password": password,
      "language":language,
      "Devicetype": "android",
      "Deviceid": "token",
    });
    //print(response.body);
    var extractdata = json.decode(response.body); 
    if (extractdata['status'] == 1) {
      return extractdata;
    } else {
      return extractdata;
    }
  }
  Future<dynamic> get_session_list(count) async {
    var user_id = await this.get_userinfo('user_id'); 
    var response = await http.post(Uri.encodeFull(AUDIO_URL), headers: {
      "Accept": "application/json",
      "authorization":basicAuth,
      }, body: {
      "PHP_AUTH_USER": Username,
      "PHP_AUTH_PW": Password,
      "user_id": user_id,
      "page":count.toString(),
     
    });
    var extractdata = json.decode(response.body); //print(extractdata);
    if (extractdata['status'] == 1) {
      return extractdata;
    } else {
      return extractdata;
    }
  }
Future<dynamic> get_history_list(count) async {
    var user_id = await this.get_userinfo('user_id'); 
    var response = await http.post(Uri.encodeFull(HISAUDIO_URL), headers: {
      "Accept": "application/json",
      "authorization":basicAuth,
      }, body: {
      "PHP_AUTH_USER": Username,
      "PHP_AUTH_PW": Password,
      "user_id": user_id,
      "page":count.toString(),
     
    });
    var extractdata = json.decode(response.body); //print(extractdata);
    if (extractdata['status'] == 1) {
      return extractdata;
    } else {
      return extractdata;
    }
  }

    Future<User> login(String email, String password,String token) async{
    var response = await http.post(Uri.encodeFull(LOGIN_URL),headers: {
      "Accept": "application/json","Devicetype":"android","Deviceid":"123","authorization":basicAuth,
    }, body: {
      
      "email": email,
      "password": password
    }); print(response.body);
     var extractdata = json.decode(response.body); 
    if (extractdata['status'] == 1) {
     return new User.map(extractdata["user"]);
    } else {
      throw new Exception(extractdata['message']);
    }
   
  }

  Future<dynamic> get_user_info() async {
    var user_id = await this.get_userinfo('user_id'); 
    var response = await http.post(Uri.encodeFull(GET_USER_INFO),
        headers: {
      "Accept": "application/json","Devicetype":"android","Deviceid":"123","authorization":basicAuth,
    },
        body: {"user_id": user_id.toString()});

    var extractdata = json.decode(response.body); 
    if (extractdata['status'] == 1) {
      var db = new DatabaseHelper();
      await db.updateUser(User.map(extractdata["user"]));
      return extractdata;
    } else {
      return extractdata;
    }
  }
   Future<dynamic> image_upload_new(image) async {
   var user_id = await this.get_userinfo('user_id');
    var response = await http.post(Uri.encodeFull(IMAGE_UPLOAD),
        headers: {
      "Accept": "application/json","Devicetype":"android","Deviceid":"123","authorization":basicAuth,
    },
       
        body: {"user_id": user_id.toString(), "image": image.toString()});

    
    var extractdata = json.decode(response.body);

    if (extractdata['status'] == 1) {
      var db = new DatabaseHelper();
      await db.updateUser(User.map(extractdata["result"]));
      return extractdata;
    } else {
      return extractdata;
    }
  }

  Future<dynamic> update_audio_played_log(audio_id) async {
   var user_id = await this.get_userinfo('user_id');
    var response = await http.post(Uri.encodeFull(AUDIO_PLAYED),
        headers: {
      "Accept": "application/json","Devicetype":"android","Deviceid":"123","authorization":basicAuth,
    },
       
        body: {"user_id": user_id.toString(), "audio_id": audio_id.toString()});


    
  }

  Future<dynamic> update_user_account(
      first_name, last_name, email, phone, language) async {
    var user_id = await this.get_userinfo('user_id');
    var response = await http.post(Uri.encodeFull(UPDATE_ACCOUNT),   headers: {
      "Accept": "application/json","Devicetype":"android","Deviceid":"123","authorization":basicAuth,
    }, body: {
      "email": email.toString(),
      "first_name": first_name.toString(),
      "last_name": last_name.toString(),
      "phone": phone.toString(),
      "language": language.toString(),
      "user_id": user_id.toString()
    });
    var extractdata = json.decode(response.body);
    if (extractdata['status'] == 1) {
      var db = new DatabaseHelper();
      await db.updateUser(User.map(extractdata["result"]));
      return extractdata;
    } else {
      return extractdata;
    }
  }

  Future<dynamic> change_password(old_password, new_password) async {
    var user_id = await this.get_userinfo('user_id');
    var response = await http.post(Uri.encodeFull(CHANGE_PASSWORD), headers: {
      "Accept": "application/json","Devicetype":"android","Deviceid":"123","authorization":basicAuth,
    }, body: {
      'old_password': old_password.toString(),
      'new_password': new_password.toString(),
      'user_id': user_id.toString()
    });

    var extractdata = json.decode(response.body);

    return extractdata;
  }

  Future<dynamic> forgot_password_link(email) async { 
    var response = await http.post(Uri.encodeFull(FORGOT_PASSWORD_URL),
        headers: { "Accept": "application/json","Devicetype":"android","Deviceid":"123","authorization":basicAuth,},
        body: {"email": email.toString()});

    var extractdata = json.decode(response.body);
     return extractdata;
  }
  
  void show_alert(String text, scaffoldKey) {
    scaffoldKey.currentState
        .showSnackBar(new SnackBar(content: new Text(text)));
  }


  Future<dynamic> get_userinfo(col) async {
    var db = new DatabaseHelper();
    var res = await db.get_userinfo();
    //print(res);
    if (col == '') {
      return res;
    } else {
      return res[0]['$col'];
    }
  }
}
