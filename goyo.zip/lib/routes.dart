import 'package:flutter/material.dart';

import './pages/start/start.dart';
final routes = {
  
  '/':         (BuildContext context) => new StartPage(),
 
};