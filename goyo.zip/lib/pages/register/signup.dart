import 'package:flutter/material.dart';
import 'package:flutter_svg/flutter_svg.dart';
import 'package:goyogi/pages/homepage/homepage.dart';
import './login.dart';
import './../homepage/welcome.dart';
import './../../models/user.dart';
import './../../data/rest_ds.dart';
import './../../data/database_helper.dart';
import 'package:shared_preferences/shared_preferences.dart';

class Signuppage extends StatefulWidget {
  @override
  _SignuppageState createState() => new _SignuppageState();
}

class _SignuppageState extends State<Signuppage> {
  final GlobalKey<FormState> _formKey = GlobalKey<FormState>();
  final formKey = new GlobalKey<FormState>();
  RestDatasource api = new RestDatasource();
  final Map<String, dynamic> _formData = {
    'email': null,
    'password': null,
    'confirmpassword': null,
    'school_code': null
  };
  final scaffoldKey_reg = new GlobalKey<ScaffoldState>();
  String new_password = "";
  bool _autoValidate = false;
  bool _isLoading = false;
  List language = [
    {"id": "-1", "name": "LANGUAGE"},
    {"id": "0", "name": "All"},
    {"id": "1", "name": "Tamil"},
    {"id": "2", "name": "English"}
  ];
  String _selected_language = "-1";
  bool lang_error = false;

  String validateEmail(String value) {
    Pattern pattern =
        r'^(([^<>()[\]\\.,;:\s@\"]+(\.[^<>()[\]\\.,;:\s@\"]+)*)|(\".+\"))@((\[[0-9]{1,3}\.[0-9]{1,3}\.[0-9]{1,3}\.[0-9]{1,3}\])|(([a-zA-Z\-0-9]+\.)+[a-zA-Z]{2,}))$';
    RegExp regex = new RegExp(pattern);
    if (!regex.hasMatch(value))
      return 'Enter Valid Email';
    else
      return null;
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      key: scaffoldKey_reg,
      //Appbar
      body: SingleChildScrollView(
          child: Form(
              autovalidate: _autoValidate,
              key: _formKey,
              child: Container(
                child: Column(
                  mainAxisAlignment: MainAxisAlignment.spaceAround,
                  children: <Widget>[
                    Container(
                      padding: EdgeInsets.only(
                          top: 100, left: 40, right: 40, bottom: 20),
                      alignment: Alignment.center,
                      child: Text(
                        'Sign up',
                        style: TextStyle(
                            fontWeight: FontWeight.bold,
                            fontFamily: "MontserratBold",
                            color: Color(0XFF301258),
                            fontSize: 30),
                      ),
                    ),
                    Container(
                      padding: EdgeInsets.only(left: 30, right: 30, top: 20),
                      child: _buildEmailTextField(context),
                    ),
                    Container(
                      padding: EdgeInsets.only(left: 30, right: 30, top: 20),
                      child: _buildPasswordTextField(context),
                    ),
                    Container(
                      padding: EdgeInsets.only(left: 30, right: 30, top: 20),
                      child: _buildConfirmPasswordTextField(context),
                    ),
                    Container(
                      padding: EdgeInsets.only(left: 30, right: 30, top: 20),
                      child: _buildSchoolcodeTextField(context),
                    ),
                    Container(
                        padding: EdgeInsets.only(top: 30, left: 30, right: 30),
                        width: MediaQuery.of(context).size.width,
                        child: Container(
                            width: MediaQuery.of(context).size.width,
                            decoration: BoxDecoration(
                              border: Border(
                                  bottom: BorderSide(
                                      color: lang_error
                                          ? Colors.red
                                          : Colors.black,
                                      width: 1.0,
                                      style: BorderStyle.solid)),
                            ),
                            child: Row(
                                mainAxisAlignment:
                                    MainAxisAlignment.spaceAround,
                                children: [
                                  Container(
                                      padding: EdgeInsets.only(left: 10),
                                      child: Icon(
                                        Icons.language,
                                        size: 30,
                                        color: Color(0XFF301258),
                                      )),
                                  Expanded(
                                      child: DropdownButtonHideUnderline(
                                          child: ButtonTheme(
                                    padding: EdgeInsets.zero,
                                    alignedDropdown: true,
                                    child: DropdownButton(
                                      isExpanded: false,
                                      elevation: 4,
                                      style: new TextStyle(
                                        fontSize: 16,
                                        fontWeight: FontWeight.bold,
                                        color: Colors.black,
                                        fontFamily: "Montserrat",
                                      ),
                                      value: _selected_language,
                                      onChanged: (String newValue) {
                                        setState(() {
                                          _selected_language = newValue;
                                        });
                                      },
                                      items: language.length > 0
                                          ? language.map((item) {
                                              return new DropdownMenuItem(
                                                child: new Text(item['name']),
                                                value: item['id'].toString(),
                                              );
                                            }).toList()
                                          : null,
                                    ),
                                  )))
                                ]))),
                    lang_error
                        ? Container(
                            alignment: Alignment.centerLeft,
                            padding: EdgeInsets.only(left: 30, top: 10),
                            child: Text(
                              "Please Select Language",
                              style: TextStyle(color: Colors.red, fontSize: 12),
                            ))
                        : Container(child: null),
                    SizedBox(
                      height: 60.0,
                    ),
                    Container(
                        height: 60,
                        width: MediaQuery.of(context).size.width * 0.8,
                        child: RaisedButton(
                          color: Theme.of(context).primaryColor,
                          shape: new RoundedRectangleBorder(
                              borderRadius: new BorderRadius.circular(35.0)),
                          textColor: Colors.white,
                          child: _isLoading == false
                              ? Text(
                                  'Sign up',
                                  style: TextStyle(
                                      fontWeight: FontWeight.bold,
                                      fontFamily: "MontserratBold",
                                      color: Colors.white,
                                      fontSize: 18),
                                )
                              : CircularProgressIndicator(
                                  backgroundColor: Colors.white,
                                ),
                          onPressed: _submitForm,
                        )),
                    SizedBox(
                      height: 30.0,
                    ),
                    SizedBox(
                      height: 60.0,
                    ),
                    InkWell(
                      child: Container(
                        padding: EdgeInsets.only(top: 20, bottom: 20),
                        alignment: Alignment.bottomCenter,
                        child: Text(
                          'Back to Login',
                          style: TextStyle(
                              fontWeight: FontWeight.bold,
                              fontFamily: "MontserratBold",
                              color: Color(0XFF4d4d4d),
                              fontSize: 15),
                        ),
                      ),
                      onTap: () {
                        Navigator.push(
                            context,
                            MaterialPageRoute(
                                builder: (context) => Loginpage()));
                      },
                    )
                  ],
                ),
              ))), //Center
    ); //Scaffold
  }

  Widget _buildEmailTextField(context) {
    return TextFormField(
      style: TextStyle(
          color: Colors.black,
          fontFamily: "Montserrat",
          fontWeight: FontWeight.bold),
      decoration: InputDecoration(
          prefixIcon: Icon(
            Icons.alternate_email,
            size: 30,
            color: Color(0XFF301258),
          ),
          enabledBorder: UnderlineInputBorder(
            borderSide: BorderSide(
                color: Colors.black, width: 1.0, style: BorderStyle.solid),
          ),
          focusedBorder: UnderlineInputBorder(
              borderSide: BorderSide(color: Theme.of(context).primaryColor)),
          border: new UnderlineInputBorder(
              borderSide: new BorderSide(color: Colors.black)),
          labelStyle: new TextStyle(
              color: Colors.black,
              fontFamily: "Montserrat",
              fontWeight: FontWeight.bold),
          labelText: 'EMAIL',
          fillColor: Theme.of(context).primaryColor),
      validator: validateEmail,
      onSaved: (String value) {
        _formData['email'] = value;
      },
    );
  }

  Widget _buildSchoolcodeTextField(context) {
    return TextFormField(
      style: TextStyle(
          color: Colors.black,
          fontFamily: "Montserrat",
          fontWeight: FontWeight.bold),
      decoration: InputDecoration(
          prefixIcon: Icon(
            Icons.school,
            size: 30,
            color: Color(0XFF301258),
          ),
          enabledBorder: UnderlineInputBorder(
            borderSide: BorderSide(
                color: Colors.black, width: 1.0, style: BorderStyle.solid),
          ),
          focusedBorder: UnderlineInputBorder(
              borderSide: BorderSide(color: Theme.of(context).primaryColor)),
          border: new UnderlineInputBorder(
              borderSide: new BorderSide(color: Colors.black)),
          labelStyle: new TextStyle(
              color: Colors.black,
              fontFamily: "Montserrat",
              fontWeight: FontWeight.bold),
          labelText: 'SCHOOL CODE',
          fillColor: Theme.of(context).primaryColor),
      validator: (String value) {
        if (value.isEmpty) {
          return 'Enter School Code.';
        }
      },
      onSaved: (String value) {
        _formData['school_code'] = value;
      },
    );
  }

  Widget _buildPasswordTextField(context) {
    return TextFormField(
      obscureText: true,
      style: TextStyle(
          color: Colors.black,
          fontFamily: "Montserrat",
          fontWeight: FontWeight.bold),
      decoration: InputDecoration(
          prefixIcon: Icon(
            Icons.lock,
            size: 30,
            color: Color(0XFF301258),
          ),
          enabledBorder: UnderlineInputBorder(
            borderSide: BorderSide(
                color: Colors.black, width: 1.0, style: BorderStyle.solid),
          ),
          focusedBorder: UnderlineInputBorder(
              borderSide: BorderSide(color: Theme.of(context).primaryColor)),
          border: new UnderlineInputBorder(
              borderSide: new BorderSide(color: Colors.black)),
          labelStyle: new TextStyle(
              color: Colors.black,
              fontFamily: "Montserrat",
              fontWeight: FontWeight.bold),
          labelText: 'PASSWORD',
          fillColor: Theme.of(context).primaryColor),
      validator: (String value) {
        if (value.isEmpty) {
          return 'Enter Password';
        }
      },
      onSaved: (String value) {
        _formData['password'] = value;
        setState(() {
          new_password = value;
        });
      },
    );
  }

  Widget _buildConfirmPasswordTextField(context) {
    return TextFormField(
      obscureText: true,
      style: TextStyle(
          color: Colors.black,
          fontFamily: "Montserrat",
          fontWeight: FontWeight.bold),
      decoration: InputDecoration(
          prefixIcon: Icon(
            Icons.lock,
            size: 30,
            color: Color(0XFF301258),
          ),
          enabledBorder: UnderlineInputBorder(
            borderSide: BorderSide(
                color: Colors.black, width: 1.0, style: BorderStyle.solid),
          ),
          focusedBorder: UnderlineInputBorder(
              borderSide: BorderSide(color: Theme.of(context).primaryColor)),
          border: new UnderlineInputBorder(
              borderSide: new BorderSide(color: Colors.black)),
          labelStyle: new TextStyle(
              color: Colors.black,
              fontFamily: "Montserrat",
              fontWeight: FontWeight.bold),
          labelText: 'CONFIRM PASSWORD',
          fillColor: Theme.of(context).primaryColor),
      validator: (String value) {
        _formKey.currentState.save(); //print(_formData['new_password']);
        if (value.isEmpty) {
          return 'Enter Confirm Password';
        } else if (value != new_password) {
          return 'Confirm password is wrong';
        }
      },
      onSaved: (String value) {
        _formData['confirmpassword'] = value;
      },
    );
  }

  _submitForm() async {
    _formKey.currentState.validate();
    final form = _formKey.currentState;

    if (form.validate() && _selected_language != "-1") {
      setState(() {
        lang_error = false;
        _isLoading = true;
      });
      _formKey.currentState.save();
      SharedPreferences prefs = await SharedPreferences.getInstance();
      // String firebaseTokenId = prefs.getString('firebaseTokenId');
      String firebaseTokenId = "123";
      api
          .registration(_formData['email'], _formData['password'],
              firebaseTokenId, _formData["school_code"],_selected_language )
          .then((response) async {
        setState(() {
          _isLoading = false;
        });

        if (response["status"] == 1) {
          _formData['email'] = null;
          _formData['password'] = null;
          _formData['confirmpassword'] = null;
          _formData['school_code'] = null;
          _formKey.currentState.reset();
          User user = User.map(response['result']);
          var db = new DatabaseHelper();
          await db.saveUser(user);
          api.show_alert(response["message"], scaffoldKey_reg);
          Navigator.pushAndRemoveUntil(
              context,
              MaterialPageRoute(builder: (context) => Homepage()),
              (e) => false);
        } else {
          api.show_alert(response["message"], scaffoldKey_reg);
        }
      });
    } else {
      if (_selected_language == "-1") {
        setState(() {
          lang_error = true;
        });
      } else {
        setState(() {
          lang_error = false;
        });
      }
    }
  }
}
