import 'package:flutter/material.dart';
import 'package:flutter_svg/flutter_svg.dart';
import './signup.dart';
import './../homepage/welcome.dart';
import './../homepage/homepage.dart';
import './../../auth.dart';
import './../../data/database_helper.dart';
import './../../models/user.dart';
import './../../data/rest_ds.dart';
import './login_screen_presenter.dart';
import './forgot.dart';

class Loginpage extends StatefulWidget {
  @override
  State<StatefulWidget> createState() {
    return LoginScreenState();
  }
}

class LoginScreenState extends State<Loginpage>
    implements LoginScreenContract, AuthStateListener {
  BuildContext _ctx;
  bool InternetError = false;
  RestDatasource api = new RestDatasource();
  bool _isLoading = false;
  final formKey = new GlobalKey<FormState>();
  final scaffoldKey = new GlobalKey<ScaffoldState>();
  String errortextphone = '';
  String errortextpassword = '';
  bool app_update_status = false;
  final Map<String, dynamic> _formData = {
    'email': null,
    'password': null,
    'acceptTerms': false
  };
  final GlobalKey<FormState> _formKey = GlobalKey<FormState>();
  void _showSnackBar(String text) {
    scaffoldKey.currentState
        .showSnackBar(new SnackBar(content: new Text(text)));
  }

  LoginScreenPresenter _presenter;
  LoginScreenState() {
    _presenter = new LoginScreenPresenter(this);
    var authStateProvider = new AuthStateProvider();
    authStateProvider.subscribe(this);
  }

  @override
  void onLoginError(String errorTxt) {
    _showSnackBar(errorTxt.toString());
    setState(() => _isLoading = false);
  }

  @override
  void onLoginSuccess(User user) async {
    setState(() => _isLoading = false);
    var db = new DatabaseHelper();
    await db.saveUser(user);
    var authStateProvider = new AuthStateProvider();
    //authStateProvider.notify(AuthState.LOGGED_IN);

    Navigator.pushAndRemoveUntil(context,
        MaterialPageRoute(builder: (context) => Homepage()), (e) => false);
  }

  @override
  onAuthStateChanged(AuthState state) async {
    if (state == AuthState.LOGGED_IN) {
      Navigator.pushAndRemoveUntil(context,
          MaterialPageRoute(builder: (context) => Homepage()), (e) => false);
    }
  }

  void _submitForm() async {
    if (_formKey.currentState.validate()) {
      setState(() {
        _isLoading = true;
      });
      _formKey.currentState.save();
      /*SharedPreferences prefs = await SharedPreferences.getInstance();
      String firebaseTokenId = prefs.getString('firebaseTokenId');
      firebaseTokenId = firebaseTokenId == "" ? "0" : firebaseTokenId;*/
      String firebaseTokenId = "123";
      _presenter.doLogin(
          _formData['email'], _formData['password'], firebaseTokenId);
    }
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(backgroundColor: Colors.white,
      key: scaffoldKey,
      //Appbar
      body: SingleChildScrollView(
          child: Container(
        child: Form(
            key: _formKey,
            child: Column(
              children: <Widget>[
                Container(
                  padding:
                      EdgeInsets.only(top: 60, left: 50, right: 50, bottom: 0),
                  alignment: Alignment.center,
                  child: Image.asset("assets/images/logo.png"),
                ),
                Container(
                  padding:
                      EdgeInsets.only(left: 30, right: 30, top: 20, bottom: 10),
                  child: _buildEmailTextField(context),
                ),
                Container(
                  padding: EdgeInsets.only(left: 30, right: 30, top: 20),
                  child: _buildPasswordTextField(context),
                ),
                SizedBox(
                  height: 40.0,
                ),
                Container(
                    height: 60,
                    width: MediaQuery.of(context).size.width * 0.8,
                    child: RaisedButton(
                      color: Theme.of(context).primaryColor,
                      shape: new RoundedRectangleBorder(
                          borderRadius: new BorderRadius.circular(35.0)),
                      textColor: Colors.white,
                      child: _isLoading == false
                          ? Text(
                              'Sign in',
                              style: TextStyle(
                                  fontWeight: FontWeight.bold,
                                  fontFamily: "MontserratBold",
                                  color: Colors.white,
                                  fontSize: 18),
                            )
                          : CircularProgressIndicator(
                              backgroundColor: Theme.of(context).primaryColor,
                            ),
                      onPressed: _submitForm,
                    )),
                SizedBox(
                  height: 10.0,
                ),
                InkWell(
                  child: Container(width: MediaQuery.of(context).size.width,alignment: Alignment.topCenter,padding: EdgeInsets.all(20),
                    child: Text(
                      'Forgot password?',
                      style: TextStyle(
                          fontWeight: FontWeight.bold,
                          fontFamily: "MontserratBold",
                          color: Theme.of(context).primaryColor,
                          fontSize: 15),
                    ),
                  ),
                  onTap: () {
                    Navigator.push(context,
                        MaterialPageRoute(builder: (context) =>Forgotpasswordpage() ));
                  },
                ),
                SizedBox(
                  height: 10.0,
                ),
                InkWell(
                  child: Container(
                    alignment: Alignment.center,
                    padding: EdgeInsets.only(top: 20, bottom: 20),
                    width: MediaQuery.of(context).size.width,
                    child: Text(
                      'Don’t have account? Sign up now',
                      style: TextStyle(
                          fontWeight: FontWeight.bold,
                          fontFamily: "MontserratBold",
                          color: Color(0XFF4d4d4d),
                          fontSize: 15),
                    ),
                  ),
                  onTap: () {
                    Navigator.push(context,
                        MaterialPageRoute(builder: (context) => Welcome()));
                  },
                )
              ],
            )),
      )), //Center
    ); //Scaffold
  }

  Widget _buildEmailTextField(context) {
    return TextFormField(
      style: TextStyle(
          color: Colors.black,
          fontFamily: "Montserrat",
          fontWeight: FontWeight.bold),
      decoration: InputDecoration(
          prefixIcon: Icon(
            Icons.alternate_email,
            size: 30,
            color: Color(0XFF301258),
          ),
          enabledBorder: UnderlineInputBorder(
            borderSide: BorderSide(
                color: Color(0XFF4d4d4d), width: 1.0, style: BorderStyle.solid),
          ),
          focusedBorder: UnderlineInputBorder(
              borderSide: BorderSide(color: Theme.of(context).primaryColor)),
          border: new UnderlineInputBorder(
              borderSide: new BorderSide(color: Color(0XFF4d4d4d))),
          labelStyle: new TextStyle(
              color: Color(0XFF4d4d4d),
              fontFamily: "Montserrat",
              fontWeight: FontWeight.bold),
          labelText: 'EMAIL',
          fillColor: Theme.of(context).primaryColor),
      validator: validateEmail,
      onSaved: (String value) {
        _formData['email'] = value;
      },
    );
  }

  String validateEmail(String value) {
    Pattern pattern =
        r'^(([^<>()[\]\\.,;:\s@\"]+(\.[^<>()[\]\\.,;:\s@\"]+)*)|(\".+\"))@((\[[0-9]{1,3}\.[0-9]{1,3}\.[0-9]{1,3}\.[0-9]{1,3}\])|(([a-zA-Z\-0-9]+\.)+[a-zA-Z]{2,}))$';
    RegExp regex = new RegExp(pattern);
    if (value.isEmpty)
      return 'Please enter email.';
    else if (!regex.hasMatch(value))
      return 'Enter Valid Email';
    else
      return null;
  }

  Widget _buildPasswordTextField(context) {
    return TextFormField(
      obscureText: true,
      style: TextStyle(
          color: Colors.black,
          fontFamily: "Montserrat",
          fontWeight: FontWeight.bold),
      decoration: InputDecoration(
          prefixIcon: Icon(
            Icons.lock,
            size: 30,
            color: Color(0XFF301258),
          ),
          enabledBorder: UnderlineInputBorder(
            borderSide: BorderSide(
                color: Colors.black, width: 1.0, style: BorderStyle.solid),
          ),
          focusedBorder: UnderlineInputBorder(
              borderSide: BorderSide(color: Theme.of(context).primaryColor)),
          border: new UnderlineInputBorder(
              borderSide: new BorderSide(color: Colors.black)),
          labelStyle: new TextStyle(
              color: Colors.black,
              fontFamily: "Montserrat",
              fontWeight: FontWeight.bold),
          labelText: 'PASSWORD',
          fillColor: Theme.of(context).primaryColor),
      validator: (String value) {
        if (value.isEmpty) {
          return 'Please enter password';
        }
      },
      onSaved: (String value) {
        _formData['password'] = value;
      },
    );
  }
}
