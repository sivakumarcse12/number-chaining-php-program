import 'dart:ui' as prefix1;

import 'package:flutter/material.dart';
import './login.dart';
import 'dart:ui';
import './../../data/rest_ds.dart';

import 'package:flutter_svg/flutter_svg.dart';

class Forgotpasswordpage extends StatefulWidget {
  @override
  State<StatefulWidget> createState() {
    return ForgotpasswordScreenState();
  }
}

class ForgotpasswordScreenState extends State<Forgotpasswordpage>
     {
  BuildContext _ctx;
  bool InternetError = false;
  RestDatasource api = new RestDatasource();
  bool _isLoading = false;
  final formKey = new GlobalKey<FormState>();
  final scaffoldKey = new GlobalKey<ScaffoldState>();
  String errortextphone = '';
  String errortextpassword = '';
  bool app_update_status = false;
  String app_update_url = 'http://www.moondrumudichumatrimony.com';
  String onesignalUserId = '';
  String token = '';
  
  

  @override
  void initState() {
    // TODO: implement initState
    super.initState();
   
    
    
  }

  
  void _showSnackBar(String text) {
    scaffoldKey.currentState
        .showSnackBar(new SnackBar(content: new Text(text)));
  }

  

  Widget _buildEmailTextField() {
    return TextFormField(
      style: TextStyle(
        color: Colors.black,fontFamily: "Montserrat"
      ),
      decoration: InputDecoration(
          enabledBorder: UnderlineInputBorder(
            borderSide: BorderSide(
                color: Colors.black, width: 1.0, style: BorderStyle.solid),
          ),
          focusedBorder:
              UnderlineInputBorder(borderSide: BorderSide(color: Theme.of(context).primaryColor)),
          border: new UnderlineInputBorder(
              borderSide: new BorderSide(color: Colors.black)),
          labelStyle: new TextStyle(color: Colors.black,fontFamily: "Montserrat"),
          labelText: 'Email',
          fillColor: Theme.of(context).primaryColor),
      keyboardType: TextInputType.emailAddress,
      validator: validateEmail,
      onSaved: (String value) {
        _formData['email'] = value;
      },
    );
  }

  String validateEmail(String value) {
    Pattern pattern =
        r'^(([^<>()[\]\\.,;:\s@\"]+(\.[^<>()[\]\\.,;:\s@\"]+)*)|(\".+\"))@((\[[0-9]{1,3}\.[0-9]{1,3}\.[0-9]{1,3}\.[0-9]{1,3}\])|(([a-zA-Z\-0-9]+\.)+[a-zA-Z]{2,}))$';
    RegExp regex = new RegExp(pattern);
    if (!regex.hasMatch(value))
      return 'Enter Valid Email';
    else
      return null;
  }

  

  

  
  void _submitForm() {
    _formKey.currentState.validate();
    final form = _formKey.currentState;

    if (form.validate()) {
      setState(() {
        _isLoading = true;
      });
      _formKey.currentState.save();
     api.forgot_password_link(_formData['email']).then((response) {
    
      setState(() {
         _isLoading = false; 
        if (response["status"] == 1) {  
         
          _formKey.currentState.reset();
          api.show_alert(response["message"],scaffoldKey);
          
        
        } else {
          api.show_alert(response["message"],scaffoldKey);
        }
      });
    });
    }
  }

  final Map<String, dynamic> _formData = {
    'email': null,
    'password': null,
    'acceptTerms': false
  };
  final GlobalKey<FormState> _formKey = GlobalKey<FormState>();
  @override
  Widget build(BuildContext context) {
    _ctx = context;

    return new Scaffold(
            appBar: AppBar(
              centerTitle: true,
              title: Text(
                "Forgot Password",
                textAlign: TextAlign.center,
                style: TextStyle(fontSize: 18,fontFamily: "MontserratBold"),
              ),
            ),
            key: scaffoldKey,
            body: new SingleChildScrollView(
                child: Column(children: <Widget>[
              new Container(
                  child: SingleChildScrollView(
                child: Padding(
                  padding:
                      EdgeInsets.only(left: 50, right: 50, top: 50, bottom: 20),
                  child: SvgPicture.asset(
                    "assets/images/logo.svg",
                    width: 150,
                  ),
                ),
              )),
              new Container(
                decoration: BoxDecoration(),
                padding: EdgeInsets.all(10),
                child: Center(
                  child: SingleChildScrollView(
                    child: Container(
                      child: Form(
                        key: _formKey,
                        child: Column(
                          children: <Widget>[
                            Container(
                                padding: EdgeInsets.only(left: 10, right: 10),
                                child: Container(
                                    width:
                                        MediaQuery.of(context).size.width * 1,
                                    child: _buildEmailTextField())),
                          
                            SizedBox(
                              height: 40.0,
                            ),
                            Container(
                                height: 60,
                                width: MediaQuery.of(context).size.width * 0.8,
                                child: RaisedButton(
                                  color: Theme.of(context).primaryColor,
                                  shape: new RoundedRectangleBorder(
                                      borderRadius:
                                          new BorderRadius.circular(35.0)),
                                  textColor: Colors.white,
                                  child: _isLoading == false
                                      ? Text(
                                          'Submit',
                                          style: TextStyle(
                                              //fontWeight: FontWeight.bold,
                                              color: Colors.white,
                                              fontFamily: "MontserratBold",
                                              fontSize: 18),
                                        )
                                      : CircularProgressIndicator(
                                          backgroundColor:
                                              Theme.of(context).primaryColor,
                                        ),
                                  onPressed: _submitForm,
                                )),
                           
                            SizedBox(
                              height: 40.0,
                            ),
                             Container(
                                width: MediaQuery.of(context).size.width * 0.9,
                                alignment: Alignment.center,
                                child: Row(
                                  mainAxisAlignment: MainAxisAlignment.center,
                                  
                                  children: <Widget>[
                                    Text(
                                      "Do you have an account?",
                                      style: TextStyle(
                                          color: Colors.black,
                                          fontFamily: "MontserratBold",
                                          fontWeight: FontWeight.w500,
                                          fontSize: 16),
                                    ),
                                    Container(  
                                        child: InkWell(
                                            onTap: () {
                                              Navigator.push(
                                                context,
                                                MaterialPageRoute(
                                                    builder: (context) =>
                                                        Loginpage()),
                                              );
                                            },
                                            child: Text(" Login",
                                                style: TextStyle(
                                                  fontSize: 16,
                                                  color: Theme.of(context)
                                                      .primaryColor,
                                                  fontWeight: FontWeight.w500,
                                                   fontFamily: "MontserratBold",
                                                ))))
                                  ],
                                )),
                          ],
                        ),
                      ),
                    ),
                  ),
                ),
              ),
            ]))
        );
  }
}