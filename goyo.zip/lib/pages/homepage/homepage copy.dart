import 'package:flutter/material.dart';
import 'package:flutter/widgets.dart';
import './listen.dart';
import 'package:flutter_svg/flutter_svg.dart';
import 'package:audioplayers/audioplayers.dart';
import './sidebar.dart';
import './../../data/rest_ds.dart';
import 'package:shimmer/shimmer.dart';

class Homepage extends StatefulWidget {
  @override
  _StartPage createState() => new _StartPage();
}

class _StartPage extends State<Homepage> {
   List taskdata;
  bool InternetError = false;
  int taskpresent = 0;
  int taskperPage = 15;
  int tasksearch_status = 0;
  int task_loading = 0;
  String task_time;
  var items = List<String>();
  RestDatasource api = new RestDatasource();
  ScrollController _favscrollController = new ScrollController();
  TextEditingController favsearchController = new TextEditingController();
  final GlobalKey<RefreshIndicatorState> _favrefreshIndicatorKey =
      new GlobalKey<RefreshIndicatorState>();
  final GlobalKey<FormState> _formKey = GlobalKey<FormState>();
  final scaffoldKey_active = new GlobalKey<ScaffoldState>();
   final timecontroller = TextEditingController();
  AudioPlayer audioPlayer = new AudioPlayer();
  bool _progressBarActive = false;
  Color initial_color = Colors.black;
  bool _playbutton1 = true;
  bool _playbutton2 = true;
  bool _playbutton3 = true;
  int current_play;
  int result;

  @override
  void initState() {
    // TODO: implement initState
    super.initState();
    audioPlayer.onPlayerCompletion.listen((event) {
      setState(() {
        initial_color = Colors.black;
        _playbutton1 = true;
        _playbutton2 = true;
        _playbutton3 = true;
      });
    });
  }

  load() async {
    audioPlayer.onPlayerCompletion.listen((event) {
      setState(() {
        initial_color = Colors.black;
        _playbutton1 = true;
        _playbutton2 = true;
        _playbutton3 = true;
      });
    });
  }
   get_session_list(count) {
    api.get_session_list(count).then((response) {
      setState(() {
        if (response["status"] == 1) {
          taskdata = response["task_pending_array"];
        } else {
          taskdata = [];
          tasksearch_status = 1;
        }
      });
    });
  }

  get_session_list_ajax(count) {
    api.get_session_list(count).then((response) {
      setState(() {
        task_loading = 0;
        if (response["status"] == 1) {
          List tempList = new List();
          //data = response["user_list"];

          for (int i = 0; i < response["task_pending_array"].length; i++) {
            tempList.add(response['task_pending_array'][i]);
          }

          taskdata.addAll(tempList);
        } else {
          tasksearch_status = 1;
        }
      });
    });
  }

 

  void loadMore() {
    setState(() {
      taskpresent = taskpresent + 1;
      task_loading = 1;
      this.get_session_list_ajax(taskpresent);
    });
  }

  Future<Null> _favrefresh() {
    taskdata = null;
    this.get_session_list(0);
    taskpresent = 0;

    setState(() {
      taskdata = null;
    });
  }

  @override
  void dispose() {
    super.dispose();
     _favscrollController.dispose();
    this.stop();
  }

  play() async {
    if (_playbutton1 == false || _playbutton2 == false) {
      this.stop();
    } else {
      setState(() {
        if (current_play == 1) {
          _playbutton1 = false;
          _playbutton2 = true;
          _playbutton3 = true;
        } else if (current_play == 2) {
          _playbutton1 = true;
          _playbutton2 = false;
          _playbutton3 = true;
        } else if (current_play == 3) {
          _playbutton1 = true;
          _playbutton2 = true;
          _playbutton3 = false;
        }
        initial_color = Colors.red[400];
      });
      if (current_play == 3) {
        current_play = 1;
      }
      String url = "https://www.pictuscode.com/kural/y" +
          current_play.toString() +
          ".wav";
      result = await audioPlayer.play(url);
      if (result == 1) {
        setState(() {
          //initial_color=Colors.white;
        });
      }
    }

    //if(_playbutton==true){ stop();}
  }

  pause() async {
    int result = await audioPlayer.pause();
  }

  stop() async {
    int result = await audioPlayer.stop();
    setState(() {
      initial_color = Colors.black;
      _playbutton1 = true;
      _playbutton2 = true;
      _playbutton3 = true;
    });
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold( key: scaffoldKey_active,
      
      backgroundColor: Colors.white,
      appBar: PreferredSize(
          preferredSize: Size.fromHeight(150.0), // here the desired height
          child: AppBar(
              leading:InkWell(child: Container(
                  padding: EdgeInsets.all(15),
                  width: 25,
                  child: SvgPicture.asset("assets/images/menu.svg")),onTap: (){
                    Navigator.push(context, MaterialPageRoute(builder: (context)=>Sidebar()));
                  },),
              title: Text(
                "GoYogi",
                style: TextStyle(
                    fontFamily: "MontserratBold",
                    fontSize: 18,
                    color: Colors.white),
              ),
              backgroundColor: Theme.of(context).primaryColor,
              centerTitle: true,
              bottom: PreferredSize(
                preferredSize: const Size.fromHeight(50.0),
                child: Container(
                  padding: EdgeInsets.only(bottom: 20),
                  alignment: Alignment.center,
                  child: Text(
                    "MY CLASSES",
                    style: TextStyle(
                        fontFamily: "MontserratBold",
                        fontSize: 18,
                        color: Colors.white),
                  ),
                ),
              ))),
      body: taskdata == null
          ? Container(
              //color: Theme.of(context).primaryColor,

              child: Column(children: <Widget>[
              Expanded(
                child: Container(
                    color: Colors.white,
                    child: new SingleChildScrollView(
                        child: add_static(context, 2))),
              )
            ]))
          :SingleChildScrollView(
        child: Container(
          padding: EdgeInsets.only(
              left: MediaQuery.of(context).size.width * 0.05,
              right: MediaQuery.of(context).size.width * 0.05,
              top: 10,
              bottom: 20),
          child: Column(
            children: <Widget>[
              InkWell(
                  child: Container(
                    padding: EdgeInsets.only(bottom: 20, top: 20),
                    decoration: BoxDecoration(
                        border:
                            Border(bottom: BorderSide(color: Colors.black))),
                    child: Row(
                      children: <Widget>[
                        Container(
                          child: Image.asset("assets/images/l1.png"),
                          width: MediaQuery.of(context).size.width * 0.2,
                        ),
                        Container(
                            padding: EdgeInsets.only(left: 10),
                            width: MediaQuery.of(context).size.width * 0.5,
                            child: Column(
                              children: <Widget>[
                                Container(
                                    width:
                                        MediaQuery.of(context).size.width * 0.5,
                                    child: Text(
                                      "GoYoga Level - 1",
                                      style: TextStyle(
                                          fontFamily: "Courgette",
                                          fontSize: 22,
                                          color: Color(0XFF4d4d4d)),
                                    )),
                                Container(
                                  width:
                                      MediaQuery.of(context).size.width * 0.5,
                                  padding: EdgeInsets.only(top: 5),
                                  alignment: Alignment.centerLeft,
                                  child: Row(
                                    mainAxisAlignment: MainAxisAlignment.start,
                                    children: <Widget>[
                                      Container(
                                        child: Icon(
                                          Icons.access_time,
                                          size: 15,
                                        ),
                                      ),
                                      Container(
                                          margin: EdgeInsets.only(left: 5),
                                          child: Text(
                                            "15 Min",
                                            style: TextStyle(
                                                fontFamily: "Courgette",
                                                fontSize: 12,
                                                color: Color(0XFF4d4d4d)),
                                          )),
                                    ],
                                  ),
                                ),
                              ],
                            )),
                        Container(
                            alignment: Alignment.center,
                            padding: EdgeInsets.only(left: 20),
                            child: InkWell(
                              child: Container(
                                height: 50,
                                width: 50,
                                child: Center(
                                    child: Icon(
                                  _playbutton1 == true
                                      ? Icons.play_arrow
                                      : Icons.stop,
                                  color: Theme.of(context).primaryColor,
                                  size: 30,
                                )),
                                decoration: BoxDecoration(
                                    color: Color(0XFFf7f6fc),
                                    border:
                                        Border.all(color: Color(0XFFE1E1E1)),
                                    borderRadius: BorderRadius.circular(25)),
                              ),
                              onTap: () {
                                setState(() {
                                  current_play = 1;
                                });
                                this.play();
                              },
                            ))
                      ],
                    ),
                  ),
                  onTap: () {
                   
                  }),
              Container(
                padding: EdgeInsets.only(bottom: 20, top: 20),
                decoration: BoxDecoration(
                    border: Border(bottom: BorderSide(color: Colors.black))),
                child: Row(
                  children: <Widget>[
                    Container(
                      child: Image.asset("assets/images/l2.png"),
                      width: MediaQuery.of(context).size.width * 0.2,
                    ),
                    Container(
                        padding: EdgeInsets.only(left: 10),
                        width: MediaQuery.of(context).size.width * 0.5,
                        child: Column(
                          children: <Widget>[
                            Container(
                                width: MediaQuery.of(context).size.width * 0.5,
                                child: Text(
                                  "GoYoga Level - 2",
                                  style: TextStyle(
                                      fontFamily: "Courgette",
                                      fontSize: 22,
                                      color: Color(0XFF4d4d4d)),
                                )),
                            Container(
                              width: MediaQuery.of(context).size.width * 0.5,
                              padding: EdgeInsets.only(top: 5),
                              alignment: Alignment.centerLeft,
                              child: Row(
                                mainAxisAlignment: MainAxisAlignment.start,
                                children: <Widget>[
                                  Container(
                                    child: Icon(
                                      Icons.access_time,
                                      size: 15,
                                    ),
                                  ),
                                  Container(
                                      margin: EdgeInsets.only(left: 5),
                                      child: Text(
                                        "15 Min",
                                        style: TextStyle(
                                            fontFamily: "Courgette",
                                            fontSize: 12,
                                            color: Color(0XFF4d4d4d)),
                                      )),
                                ],
                              ),
                            ),
                          ],
                        )),
                    Container(
                        alignment: Alignment.center,
                        padding: EdgeInsets.only(left: 20),
                        child: InkWell(
                          child: Container(
                            height: 50,
                            width: 50,
                            child: Center(
                                child: Icon(
                              _playbutton2 == true
                                  ? Icons.play_arrow
                                  : Icons.stop,
                              color: Theme.of(context).primaryColor,
                              size: 30,
                            )),
                            decoration: BoxDecoration(
                                color: Color(0XFFf7f6fc),
                                border: Border.all(color: Color(0XFFE1E1E1)),
                                borderRadius: BorderRadius.circular(25)),
                          ),
                          onTap: () {
                            setState(() {
                              current_play = 2;
                            });
                            this.play();
                          },
                        ))
                  ],
                ),
              ),
            ],
          ),
        ),
      ),
    );
  }
  Widget add_static(context,int itemcount){
  Color common_shimmingcolor=Colors.grey[200];
   List<Widget> list = new List<Widget>();
    for(var i = 0; i < itemcount; i++){
        list.add(   Container( decoration: new BoxDecoration(
                                    boxShadow: [
                                      new BoxShadow(
                                        color: Colors.white,
                                        blurRadius: 20.0,
                                      ),
                                    ],
                                    border: Border(
                                            bottom: BorderSide(
                                              //                    <--- top side
                                              color: Color(0XFFededed),
                                              width: 10.0,
                                            ),
                                          )
                                  ),
                                  padding: EdgeInsets.only(
                                      left: 10, top: 10, right: 10),
                                  child: Column(
                                    children: <Widget>[
                                      Container(
                                          decoration: new BoxDecoration(
                                              border: Border(
                                            bottom: BorderSide(
                                              //                    <--- top side
                                              color: Color(0XFFededed),
                                              width: 1.0,
                                            ),
                                          )),
                                          padding: EdgeInsets.all(10),
                                          child: Row(
                                            children: <Widget>[
                                              Shimmer.fromColors(
                                            baseColor: common_shimmingcolor,
                                            highlightColor: Colors.white,
                                            child: Container(
                                                  decoration: BoxDecoration(
                                                      color: common_shimmingcolor,
                                                     
                                                      borderRadius:
                                                          new BorderRadius
                                                              .circular(25.0)),
                                                  width: 50,
                                                  height: 50,
                                                  child: null)),
                                              Container( width: MediaQuery.of(context)
                                                          .size
                                                          .width *
                                                      0.715,
                                                  padding:
                                                      EdgeInsets.only(left: 10),
                                                  child: Column(
                                                    crossAxisAlignment:
                                                        CrossAxisAlignment
                                                            .start,
                                                    children: <Widget>[
                                                     Row(
                                                        mainAxisAlignment:
                                                            MainAxisAlignment
                                                                .spaceBetween,
                                                        children: <Widget>[
                                                          Shimmer.fromColors(
                                            baseColor: common_shimmingcolor,
                                            highlightColor: Colors.white,
                                            child: Container(  width: MediaQuery.of(context)
                                                          .size
                                                          .width *
                                                      0.315,
                                                        height: 10,
                                                        decoration: BoxDecoration(color: common_shimmingcolor,borderRadius: BorderRadius.circular(10)),
                                                      child: null,
                                                          )),
                                                          Container(
                                                              child: Row(
                                                            children: <Widget>[
                                                              SvgPicture.asset(
                                                                "assets/images/icons/chat.svg",
                                                                width: 20,
                                                                color: Theme.of(
                                                                        context)
                                                                    .primaryColor,
                                                              ),
                                                              Padding(
                                                                padding: EdgeInsets
                                                                    .only(
                                                                        left:
                                                                            5),
                                                              ),
                                                               Shimmer.fromColors(
                                            baseColor: common_shimmingcolor,
                                            highlightColor: Colors.white,
                                            child:Container(  decoration: BoxDecoration(color: common_shimmingcolor,borderRadius: BorderRadius.circular(10)), width: MediaQuery.of(context)
                                                          .size
                                                          .width *
                                                      0.15,
                                                        height: 10,
                                                      child: null,
                                                          ))
                                                            ],
                                                          )),
                                                        ],
                                                      ),
                                                      Padding(padding: EdgeInsets.only(top: 5),),
                                                       Shimmer.fromColors(
                                            baseColor: common_shimmingcolor,
                                            highlightColor: Colors.white,
                                            child:Container(  decoration: BoxDecoration(color: common_shimmingcolor,borderRadius: BorderRadius.circular(10)), width: MediaQuery.of(context)
                                                          .size
                                                          .width *
                                                      0.315,
                                                        height: 10,
                                                      child: null,
                                                          ))
                                                    ],
                                                  ))
                                            ],
                                          )),
                                          
                                      Container(
                                        padding: EdgeInsets.only(
                                            left: 10, top: 10, bottom: 10),
                                        child: Row(
                                          mainAxisAlignment:
                                              MainAxisAlignment.spaceBetween,
                                          children: <Widget>[
                                            Container(
                                              child: Shimmer.fromColors(
                                            baseColor: common_shimmingcolor,
                                            highlightColor: Colors.white,
                                            child: Container(  decoration: BoxDecoration(color: common_shimmingcolor,borderRadius: BorderRadius.circular(10)), width: MediaQuery.of(context)
                                                          .size
                                                          .width *
                                                      0.315,
                                                        height: 10,
                                                      child: null,
                                                          ))
                                            ),
                                            Padding(padding: EdgeInsets.only(left: 10),),
                                            Container(
                                              child:  Shimmer.fromColors(
                                            baseColor: common_shimmingcolor,
                                            highlightColor: Colors.white,
                                            child:Container(  decoration: BoxDecoration(color: common_shimmingcolor,borderRadius: BorderRadius.circular(10)), width: MediaQuery.of(context)
                                                          .size
                                                          .width *
                                                      0.315,
                                                        height: 10,
                                                      child: null,
                                                          )),
                                            )
                                          ],
                                        ),
                                      ),
                                      Container(
                                        padding: EdgeInsets.only(
                                            left: 10, top: 0, bottom: 10),
                                        child: Row(
                                          mainAxisAlignment:
                                              MainAxisAlignment.start,
                                          children: <Widget>[
                                            Container(
                                              child: SvgPicture.asset(
                                                  "assets/images/icons/location.svg",
                                                  width: 15),
                                            ),
                                            Container(
                                              padding:
                                                  EdgeInsets.only(left: 10),
                                              child: Shimmer.fromColors(
                                            baseColor: common_shimmingcolor,
                                            highlightColor: Colors.white,
                                            child: Container(  decoration: BoxDecoration(color: common_shimmingcolor,borderRadius: BorderRadius.circular(10)), width: MediaQuery.of(context)
                                                          .size
                                                          .width *
                                                      0.315,
                                                        height: 10,
                                                      child: null,
                                                          )),
                                            )
                                          ],
                                        ),
                                      ),
                                      Container(
                                        padding: EdgeInsets.only(
                                            left: 10, top: 0, bottom: 10),
                                        child: Row(
                                          mainAxisAlignment:
                                              MainAxisAlignment.start,
                                          children: <Widget>[
                                            Container(
                                              child: SvgPicture.asset(
                                                  "assets/images/icons/lock.svg",
                                                  width: 15),
                                            ),
                                            Container(
                                              padding:
                                                  EdgeInsets.only(left: 10),
                                              child:  Shimmer.fromColors(
                                            baseColor: common_shimmingcolor,
                                            highlightColor: Colors.white,
                                            child:Container(  decoration: BoxDecoration(color: common_shimmingcolor,borderRadius: BorderRadius.circular(10)), width: MediaQuery.of(context)
                                                          .size
                                                          .width *
                                                      0.315,
                                                      height: 10,
                                                      child: null,
                                              )),
                                            )
                                          ],
                                        ),
                                      )
                                    ],
                                  )));                        
         
                          
    }
     return new Column(children: list); 
}
}
