import 'package:flutter/material.dart';
import 'package:flutter/widgets.dart';
import 'package:flutter_svg/flutter_svg.dart';
import './drawer.dart';
import 'package:audioplayers/audioplayers.dart';
import './homepage.dart';
import './../../data/rest_ds.dart';

class Sidebar extends StatefulWidget {
  @override
  _SidebarPage createState() => new _SidebarPage();
}

class _SidebarPage extends State<Sidebar> {
  bool _giveVerse=true;
  String name="Guest";
  String image='https://www.google.com/s2/u/3/photos/public/AIbEiAIAAABDCLv6mMmhntPaciILdmNhcmRfcGhvdG8qKDlmYzZmOWNlZTNiMzdmZGJhYjFjNjg3YmY0MGQ2OTUyNzJjYTU2NmIwAQ5vlAatx3vzIshPINoViIaBU9YZ?sz=100';
   RestDatasource api = new RestDatasource();
  @override
  void initState() {
    // TODO: implement initState
    super.initState();
    this.get_name();
    this.get_image();
  }
  get_name()async{
    setState(() async{
      name=await api.get_userinfo("first_name");
    });
  }
  get_image()async{
    String image1=await api.get_userinfo("pro_pic");
    setState(() {
     
      image=image1;
    });
  }
 final GlobalKey<ScaffoldState> _scaffoldKey = new GlobalKey<ScaffoldState>();
  @override
  Widget build(BuildContext context) {
    return Scaffold(drawer: get_drawer(context), key: _scaffoldKey,
      backgroundColor: Colors.white,
      appBar: AppBar(
        elevation: 0,
        leading: Container(
            padding: EdgeInsets.all(15),
            width: 25,
            child: SvgPicture.asset("assets/images/menu.svg")),
        title: Text(
          "GoYogi",
          style: TextStyle(
              fontFamily: "MontserratBold", fontSize: 18, color: Colors.white),
        ),
        backgroundColor: Theme.of(context).primaryColor,
        centerTitle: true,
      ),
      body: SingleChildScrollView(
        child: Container(
            padding: EdgeInsets.only(bottom: 20),
            child: Column(
              children: <Widget>[
                Stack(
                  children: <Widget>[
                    Container(
                      width: MediaQuery.of(context).size.width,
                      height: MediaQuery.of(context).size.height / 8,
                      child: null,
                      decoration:
                          BoxDecoration(color: Theme.of(context).primaryColor),
                    ),
                    Container(
                      decoration: BoxDecoration(
                          color: Color(0XFFf2f2f2),
                          borderRadius: BorderRadius.circular(8)),
                      width: MediaQuery.of(context).size.width,
                      height: MediaQuery.of(context).size.height / 8,
                      alignment: Alignment.center,
                      child: Container(
                        child: Container(
                          width: MediaQuery.of(context).size.width,
                          child: Row(
                            mainAxisAlignment: MainAxisAlignment.spaceBetween,
                            mainAxisSize: MainAxisSize.max,
                            crossAxisAlignment: CrossAxisAlignment.center,
                            children: <Widget>[
                              Container(
                                padding: EdgeInsets.only(left: 20),
                                child: CircleAvatar(
                                  radius: 30.0,
                                  backgroundImage: NetworkImage(
                                     image==""? 'https://www.google.com/s2/u/3/photos/public/AIbEiAIAAABDCLv6mMmhntPaciILdmNhcmRfcGhvdG8qKDlmYzZmOWNlZTNiMzdmZGJhYjFjNjg3YmY0MGQ2OTUyNzJjYTU2NmIwAQ5vlAatx3vzIshPINoViIaBU9YZ?sz=100':image),
                                  backgroundColor: Colors.transparent,
                                ),
                              ),
                              Container(
                                width: MediaQuery.of(context).size.width * 0.45,
                                child: Column(
                                  crossAxisAlignment: CrossAxisAlignment.start,
                                  mainAxisAlignment: MainAxisAlignment.center,
                                  children: <Widget>[
                                    Expanded(
                                        child: Container(
                                      padding: EdgeInsets.only(
                                          top: 15, left: 10, right: 20),
                                      child: Text(
                                        name==""?"Guest ":name,
                                        style: TextStyle(
                                            fontFamily: "Courgette",
                                            fontSize: 22,
                                            color: Color(0XFF4d4d4d)),
                                      ),
                                    )),
                                    Expanded(
                                        child: Container(
                                      padding: EdgeInsets.only(
                                          top: 5, left: 10, right: 20),
                                      child: Text(
                                        "View Profile",
                                        style: TextStyle(
                                            fontFamily: "Montserrat",
                                            fontSize: 12,
                                            color: Color(0XFF4d4d4d)),
                                      ),
                                    )),
                                  ],
                                ),
                              ),
                              Expanded(
                                  child: Container(
                                width: MediaQuery.of(context).size.width * 0.1,
                                child: Icon(
                                  Icons.chevron_right,
                                  size: 30,
                                ),
                              ))
                            ],
                          ),
                        ),
                      ),
                      margin: EdgeInsets.only(
                          left: MediaQuery.of(context).size.width * 0.1,
                          right: MediaQuery.of(context).size.width * 0.1,
                          top: MediaQuery.of(context).size.height / 15),
                    ),
                  ],
                ),
                Container(
                  padding: EdgeInsets.only(
                    top: 20,
                    left: 20,
                  ),
                  child: Column(
                    children: <Widget>[
                      Container(
                        padding: EdgeInsets.only(bottom: 20, top: 10),
                        width: MediaQuery.of(context).size.width,
                        decoration: BoxDecoration(
                            border: Border(
                                bottom: BorderSide(color: Color(0XFFE1E1E1)))),
                        child:InkWell(child:  Row(
                          children: <Widget>[
                            Container(
                              padding: EdgeInsets.all(10),
                              child: SvgPicture.asset(
                                "assets/images/setting.svg",
                                width: 30,
                                height: 30,
                              ),
                              decoration: BoxDecoration(
                                  borderRadius: BorderRadius.circular(15),
                                  color: Theme.of(context).primaryColor),
                            ),
                            Expanded(
                                child: Container(
                              width: MediaQuery.of(context).size.width * 0.6,
                              padding:
                                  EdgeInsets.only(top: 0, left: 20, right: 20),
                              child: Text(
                                "Account",
                                style: TextStyle(
                                    fontFamily: "Courgette",
                                    fontSize: 18,
                                    color: Color(0XFF4d4d4d)),
                              ),
                            )),
                            Container(
                              padding: EdgeInsets.only(right: 20),
                              alignment: Alignment.centerRight,
                              child: Icon(
                                Icons.chevron_right,
                                size: 30,
                              ),
                            )
                          ],
                        ),onTap: (){
                           _scaffoldKey.currentState.openDrawer(); 
                        },),
                      ),
                      Container(
                        padding: EdgeInsets.only(bottom: 20, top: 10),
                        width: MediaQuery.of(context).size.width,
                        decoration: BoxDecoration(
                            border: Border(
                                bottom: BorderSide(color: Color(0XFFE1E1E1)))),
                        child: Row(
                          children: <Widget>[
                            Container(
                              padding: EdgeInsets.all(10),
                              child: SvgPicture.asset(
                                "assets/images/alarm.svg",
                                width: 30,
                                height: 30,
                              ),
                              decoration: BoxDecoration(
                                  borderRadius: BorderRadius.circular(15),
                                  color: Theme.of(context).primaryColor),
                            ),
                            Expanded(
                                child: Container(
                              width: MediaQuery.of(context).size.width * 0.6,
                              padding:
                                  EdgeInsets.only(top: 0, left: 20, right: 20),
                              child: Text(
                                "Notification",
                                style: TextStyle(
                                    fontFamily: "Courgette",
                                    fontSize: 18,
                                    color: Color(0XFF4d4d4d)),
                              ),
                            )),
                            Container(
                              padding: EdgeInsets.only(right: 20),
                              alignment: Alignment.centerRight,
                              child: Switch(activeColor: Theme.of(context).primaryColor,
                                value: _giveVerse,
                                onChanged: (bool newValue) {
                                  setState(() {
                                    _giveVerse = newValue;
                                  });
                                },
                              ),
                            )
                          ],
                        ),
                      ),
                      Container(
                        padding: EdgeInsets.only(bottom: 20, top: 10),
                        width: MediaQuery.of(context).size.width,
                        decoration: BoxDecoration(
                            border: Border(
                                bottom: BorderSide(color: Color(0XFFE1E1E1)))),
                        child: Row(
                          children: <Widget>[
                            Container(
                              padding: EdgeInsets.all(10),
                              child: SvgPicture.asset(
                                "assets/images/setting.svg",
                                width: 30,
                                height: 30,
                              ),
                              decoration: BoxDecoration(
                                  borderRadius: BorderRadius.circular(15),
                                  color: Theme.of(context).primaryColor),
                            ),
                            Expanded(
                                child: Container(
                              width: MediaQuery.of(context).size.width * 0.6,
                              padding:
                                  EdgeInsets.only(top: 0, left: 20, right: 20),
                              child: Text(
                                "Account",
                                style: TextStyle(
                                    fontFamily: "Courgette",
                                    fontSize: 18,
                                    color: Color(0XFF4d4d4d)),
                              ),
                            )),
                            Container(
                              padding: EdgeInsets.only(right: 20),
                              alignment: Alignment.centerRight,
                              child: Icon(
                                Icons.chevron_right,
                                size: 30,
                              ),
                            )
                          ],
                        ),
                      ),
                      Container(
                        padding: EdgeInsets.only(bottom: 20, top: 10),
                        width: MediaQuery.of(context).size.width,
                        decoration: BoxDecoration(
                            border: Border(
                                bottom: BorderSide(color: Color(0XFFE1E1E1)))),
                        child: Row(
                          children: <Widget>[
                            Container(
                              padding: EdgeInsets.all(10),
                              child: SvgPicture.asset(
                                "assets/images/contact.svg",
                                width: 30,
                                height: 30,
                                color: Colors.white,
                              ),
                              decoration: BoxDecoration(
                                  borderRadius: BorderRadius.circular(15),
                                  color: Theme.of(context).primaryColor),
                            ),
                            Expanded(
                                child: Container(
                              width: MediaQuery.of(context).size.width * 0.6,
                              padding:
                                  EdgeInsets.only(top: 0, left: 20, right: 20),
                              child: Text(
                                "Contact Us",
                                style: TextStyle(
                                    fontFamily: "Courgette",
                                    fontSize: 18,
                                    color: Color(0XFF4d4d4d)),
                              ),
                            )),
                            Container(
                              padding: EdgeInsets.only(right: 20),
                              alignment: Alignment.centerRight,
                              child: Icon(
                                Icons.chevron_right,
                                size: 30,
                              ),
                            )
                          ],
                        ),
                      ),
                      Container(
                        padding: EdgeInsets.only(bottom: 20, top: 10),
                        width: MediaQuery.of(context).size.width,
                        decoration: BoxDecoration(
                            border: Border(
                                bottom: BorderSide(color: Color(0XFFE1E1E1)))),
                        child: Row(
                          children: <Widget>[
                            Container(
                              padding: EdgeInsets.all(10),
                              child: SvgPicture.asset(
                                  "assets/images/question.svg",
                                  width: 30,
                                  height: 30,
                                  color: Colors.white),
                              decoration: BoxDecoration(
                                  borderRadius: BorderRadius.circular(15),
                                  color: Theme.of(context).primaryColor),
                            ),
                            Expanded(
                                child: Container(
                              width: MediaQuery.of(context).size.width * 0.6,
                              padding:
                                  EdgeInsets.only(top: 0, left: 20, right: 20),
                              child: Text(
                                "FAQ'S",
                                style: TextStyle(
                                    fontFamily: "Courgette",
                                    fontSize: 18,
                                    color: Color(0XFF4d4d4d)),
                              ),
                            )),
                            Container(
                              padding: EdgeInsets.only(right: 20),
                              alignment: Alignment.centerRight,
                              child: Icon(
                                Icons.chevron_right,
                                size: 30,
                              ),
                            )
                          ],
                        ),
                      ),
                      Container(
                        padding: EdgeInsets.only(bottom: 20, top: 10),
                        width: MediaQuery.of(context).size.width,
                        decoration: BoxDecoration(
                            border: Border(
                                bottom: BorderSide(color: Color(0XFFE1E1E1)))),
                        child: Row(
                          children: <Widget>[
                            Container(
                              padding: EdgeInsets.all(10),
                              child: SvgPicture.asset("assets/images/exct.svg",
                                  width: 30, height: 30, color: Colors.white),
                              decoration: BoxDecoration(
                                  borderRadius: BorderRadius.circular(15),
                                  color: Theme.of(context).primaryColor),
                            ),
                            Expanded(
                                child: Container(
                              width: MediaQuery.of(context).size.width * 0.6,
                              padding:
                                  EdgeInsets.only(top: 0, left: 20, right: 20),
                              child: Text(
                                "About Us",
                                style: TextStyle(
                                    fontFamily: "Courgette",
                                    fontSize: 18,
                                    color: Color(0XFF4d4d4d)),
                              ),
                            )),
                            Container(
                              padding: EdgeInsets.only(right: 20),
                              alignment: Alignment.centerRight,
                              child: Icon(
                                Icons.chevron_right,
                                size: 30,
                              ),
                            )
                          ],
                        ),
                      )
                    ],
                  ),
                )
              ],
            )),
      ),
    );
  }
}
