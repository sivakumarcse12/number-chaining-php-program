import 'package:flutter/material.dart';
import 'package:flutter/material.dart' as prefix0;
import 'dart:ui';
import './../../data/rest_ds.dart';
import 'package:image_cropper/image_cropper.dart';
import 'package:image_picker/image_picker.dart';
import 'dart:io';
import 'dart:convert';
import 'package:shimmer/shimmer.dart';
import 'package:cached_network_image/cached_network_image.dart';

class Profilepage extends StatefulWidget {
  @override
  State<StatefulWidget> createState() {
    return ProfilepageScreenState();
  }
}

class ProfilepageScreenState extends State<Profilepage> {
  BuildContext _ctx;
  bool InternetError = false;
  RestDatasource api = new RestDatasource();
  bool _isLoading = false;
  bool _about_loader = true;
  final formKey = new GlobalKey<FormState>();
  final scaffoldKey = new GlobalKey<ScaffoldState>();
  bool about_on = true;
  List about_task;
  ScrollController _scrollController = new ScrollController();
  File file;
  File croppedFile;
  String img = '';
  String first_name;
  String last_name;
  String email;
  String zipcode;
  String phone;
  List language = [
    {"id": "0", "name": "All"},
    {"id": "1", "name": "Tamil"},
    {"id": "2", "name": "English"}
  ];
  String _selected_language="0";
  @override
  void initState() {
    // TODO: implement initState
    super.initState();
    this.get_user_info();
  }


  get_user_info() {
    api.get_user_info().then((response) {
      setState(() {
      
        if (response["status"] == 1) {
          about_task = response["user_info"]; 
          if(response['language']==1 || response['language']=="1"){
            _selected_language="1";
          }
          else if(response['language']==2 || response['language']=="2"){
             _selected_language="2";
          }
        } else {
          about_task = [];
        }
        
         
      });
      setState(() {
         _about_loader = false;
      });
    });
  }
   void _choose() async {
    //file = await ImagePicker.pickImage(source: ImageSource.camera);
    file = await ImagePicker.pickImage(source: ImageSource.gallery);
    //debugPrint(base64Encode(file.readAsBytesSync()));
    _cropImage(file);
  }

  Future _cropImage(File imageFile) async {
    croppedFile = await ImageCropper.cropImage(
      sourcePath: imageFile.path,
      maxWidth: 365,
      maxHeight: 441,
    );
    this.userImage(croppedFile);
  }

  @override
  userImage(File _image) {
    if (_image == null) return;
    String image = base64Encode(_image.readAsBytesSync());
    debugPrint(image);
    api.image_upload_new('data:image/png;base64,' + image).then((response) {
      this._showSnackBar(response['message']);
      this.get_user_info();
    });
  }

  void _submitForm() {
   formKey.currentState.validate();
    final form = formKey.currentState;

    if (form.validate()) {
      setState(() {
        _isLoading = true;
      });
      formKey.currentState.save();
      api
          .update_user_account(first_name,last_name,email,phone,_selected_language)
          .then((response) {
            this._showSnackBar(response['message']);
        setState(() {
          _isLoading = false;
         
        });
      });
    }

    
  }

  void _showSnackBar(String text) {
    scaffoldKey.currentState
        .showSnackBar(new SnackBar(content: new Text(text,style: prefix0.TextStyle(fontFamily: "Montserrat",),)));
  }

  Widget _buildfirstnameTextField() {
    return TextFormField(
      initialValue: about_task.length > 0 ? about_task[0]["first_name"] : "-",
      style: TextStyle(
        color: Colors.black,fontFamily: "Montserrat",
      ),
      decoration: InputDecoration(
          enabledBorder: UnderlineInputBorder(
            borderSide: BorderSide(
                color: Color(0XFFc5c5c5), width: 1.0, style: BorderStyle.solid),
          ),
          focusedBorder:
              UnderlineInputBorder(borderSide: BorderSide(color: Theme.of(context).primaryColor)),
          border: new UnderlineInputBorder(
              borderSide: new BorderSide(color: Colors.black)),
          labelStyle: new TextStyle(color: Color(0XFFc5c5c5),fontFamily: "Montserrat",),
          labelText: 'First Name',
          filled: true,
          fillColor: Colors.white),
     
      validator: (String value) {
        if (value.isEmpty ) {
          return 'Please enter first name.';

        
        } else {
          setState(() {
            //errortextphone = '';
          });
        }
      },
      onSaved: (String value) {
       setState(() {
         first_name=value;
       }); 
      },
    );
  }

  Widget _buildlastnameTextField() {
    return TextFormField(
      initialValue: about_task.length > 0 ? about_task[0]["last_name"] : "-",
      style: TextStyle(
        color: Colors.black,fontFamily: "Montserrat",
      ),
      decoration: InputDecoration(
          enabledBorder: UnderlineInputBorder(
            borderSide: BorderSide(
                color: Color(0XFFc5c5c5), width: 1.0, style: BorderStyle.solid),
          ),
          focusedBorder:
               UnderlineInputBorder(borderSide: BorderSide(color: Theme.of(context).primaryColor)),
          border: new UnderlineInputBorder(
              borderSide: new BorderSide(color: Colors.black)),
          labelStyle: new TextStyle(color: Color(0XFFc5c5c5),fontFamily: "Montserrat",),
          labelText: 'Last Name',
          filled: true,
          fillColor: Colors.white),
      validator: (String value) {
        if (value.isEmpty) {
           return 'Plese enter last name';

         
        } else {
          setState(() {
            //errortextphone = '';
          });
        }
      },
      onSaved: (String value) {
       setState(() {
        last_name=value; 
       });
      },
    );
  }

  String validateEmail(String value) {
    Pattern pattern =
        r'^(([^<>()[\]\\.,;:\s@\"]+(\.[^<>()[\]\\.,;:\s@\"]+)*)|(\".+\"))@((\[[0-9]{1,3}\.[0-9]{1,3}\.[0-9]{1,3}\.[0-9]{1,3}\])|(([a-zA-Z\-0-9]+\.)+[a-zA-Z]{2,}))$';
    RegExp regex = new RegExp(pattern);
    if (!regex.hasMatch(value))
      return 'Enter Valid Email';
    else
      return null;
  }

  Widget _buildEmailTextField() {
    return TextFormField(
      initialValue: about_task.length > 0 ? about_task[0]["email"] : "-",
      style: TextStyle(
        color: Colors.black,fontFamily: "Montserrat",
      ),
      decoration: InputDecoration(
          enabledBorder: UnderlineInputBorder(
            borderSide: BorderSide(
                color: Color(0XFFc5c5c5), width: 1.0, style: BorderStyle.solid),
          ),
          focusedBorder:
              UnderlineInputBorder(borderSide: BorderSide(color: Theme.of(context).primaryColor)),
          border: new UnderlineInputBorder(
              borderSide: new BorderSide(color: Colors.black)),
          labelStyle: new TextStyle(color: Color(0XFFc5c5c5),fontFamily: "Montserrat",),
          labelText: 'Email',
          filled: true,
          fillColor: Colors.white),
      validator: validateEmail,
      onSaved: (String value) {
        setState(() {
         email=value; 
        });
      },
    );
  }

  Widget _buildphoneTextField() {
    return TextFormField(
      initialValue: about_task.length > 0 ? about_task[0]["phone"] : "-",
      style: TextStyle(
        color: Colors.black,fontFamily: "Montserrat",
      ),
      decoration: InputDecoration(
          enabledBorder: UnderlineInputBorder(
            borderSide: BorderSide(
                color: Color(0XFFc5c5c5), width: 1.0, style: BorderStyle.solid),
          ),
          focusedBorder:
               UnderlineInputBorder(borderSide: BorderSide(color: Theme.of(context).primaryColor)),
          border: new UnderlineInputBorder(
              borderSide: new BorderSide(color: Colors.black)),
          labelStyle: new TextStyle(color: Color(0XFFc5c5c5),fontFamily: "Montserrat",),
          labelText: 'Phone',
          filled: true,
          fillColor: Colors.white),
      keyboardType: TextInputType.phone,
      validator: (String value) {
        if (value.isEmpty || value.length != 10) {
           return 'Phone Number must have atleast 10 chars';

         
        } else {
          setState(() {
            //errortextphone = '';
          });
        }
      },
      onSaved: (String value) {
        setState(() {
         phone=value; 
        });
      },
    );
  }

  Widget _buildzipcodeTextField() {
    return TextFormField(
      initialValue: about_task.length > 0 ? about_task[0]["zipcode"] : "-",
      style: TextStyle(
        color: Colors.black,fontFamily: "Montserrat",
      ),
      decoration: InputDecoration(
          enabledBorder: UnderlineInputBorder(
            borderSide: BorderSide(
                color: Color(0XFFc5c5c5), width: 1.0, style: BorderStyle.solid),
          ),
          focusedBorder:
              UnderlineInputBorder(borderSide: BorderSide(color: Theme.of(context).primaryColor)),
          border: new UnderlineInputBorder(
              borderSide: new BorderSide(color: Colors.black)),
          labelStyle: new TextStyle(color: Color(0XFFc5c5c5),fontFamily: "Montserrat",),
          labelText: 'Zipcode',
          filled: true,
          fillColor: Colors.white),
      keyboardType: TextInputType.phone,
      validator: (String value) {
        if (value.isEmpty ) {
          return 'Please enter zipcode';

         
        } else {
          setState(() {
            //errortextphone = '';
          });
        }
      },
      onSaved: (String value) {
       setState(() {
        zipcode=value; 
       });
      },
    );
  }

  @override
  Widget build(BuildContext context) {
    _ctx = context;

    return new Scaffold(
        appBar: AppBar(
          centerTitle: true,
          title: Text(
            "Profile",
            textAlign: TextAlign.center,
            style: TextStyle(fontSize: 18,fontFamily: "MontserratBold",),
          ),
        ),
        key: scaffoldKey,
        body: _about_loader == true
            ? Center(
                child: CircularProgressIndicator(backgroundColor: Theme.of(context).primaryColor,),
              )
            : Container(
                color: Colors.white,
                child: new SingleChildScrollView(
                  controller: _scrollController,
                  child: Column(
                    children: <Widget>[
                      Container(child:Form(key: formKey,
                        child: Column(
                          children: <Widget>[
                            Padding(
                              padding: EdgeInsets.only(top: 40),
                            ),
                         /* InkWell(onTap: _choose,
                                    splashColor: Theme.of(context)
                                        .primaryColor, // inkwell color
                                    child:   Container(
                                decoration: BoxDecoration(
                                    color: Colors.black26,
                                    image: DecorationImage(
                                      image: new CachedNetworkImageProvider(
                                        about_task.length > 0
                                            ? about_task[0]["pro_pic"]
                                            : "http://icubesolutions.com/go-yogi/media/profile/default.png",
                                      ),
                                      fit: BoxFit.fill,
                                    ),
                                    borderRadius:
                                        new BorderRadius.circular(60.0)),
                                height: 120.0,
                                width: 120.0,
                                child: null)
                                
                                ),*/
                            Padding(
                              padding: EdgeInsets.only(top: 10),
                            ),
                            Container(
                              margin: EdgeInsets.only(left: 20),
                              child: _buildfirstnameTextField(),
                            ),
                            Padding(
                              padding: EdgeInsets.all(10),
                            ),
                            Container(
                              margin: EdgeInsets.only(left: 20),
                              child: _buildlastnameTextField(),
                            ),
                            Padding(
                              padding: EdgeInsets.all(10),
                            ),
                            Container(
                              margin: EdgeInsets.only(left: 20),
                              child: _buildEmailTextField(),
                            ),
                            Padding(
                              padding: EdgeInsets.all(10),
                            ),
                            Container(
                              margin: EdgeInsets.only(left: 20),
                              child: _buildphoneTextField(),
                            ),
                            Padding(
                              padding: EdgeInsets.all(10),
                            ),
                             Container(
                              padding: EdgeInsets.only(
                                bottom: 10,
                                left:20
                              ),
                              width: MediaQuery.of(context).size.width ,
                              child: Card(
                                  child: DropdownButtonHideUnderline(
                                      child: ButtonTheme(
                                alignedDropdown: true,
                                child: DropdownButton(
                                  isExpanded: true,
                                  elevation: 0,
                                  style: new TextStyle(
                                    fontSize: 14,
                                    color: Colors.black,fontFamily: "Montserrat",
                                  ),
                                  value: _selected_language,
                                  onChanged: (String newValue) {
                                    setState(() {
                                      _selected_language = newValue;
                                    });
                                  },
                                  items: language.length > 0
                                      ? language.map((item) {
                                          return new DropdownMenuItem(
                                            child: new Text(item['name']),
                                            value: item['id'].toString(),
                                          );
                                        }).toList()
                                      : null,
                                ),
                              )))),
                            Padding(
                              padding: EdgeInsets.all(30),
                            ),
                            Container(
                                height: 60,
                                width: MediaQuery.of(context).size.width * 0.8,
                                child: RaisedButton(
                                  color: Theme.of(context).primaryColor,
                                  shape: new RoundedRectangleBorder(
                                      borderRadius:
                                          new BorderRadius.circular(35.0)),
                                  textColor: Colors.white,
                                  child: _isLoading == false
                                      ? Text(
                                          'Save',
                                          style: TextStyle(
                                              fontWeight: FontWeight.bold,
                                              color: Colors.white,fontFamily: "MontserratBold",
                                              fontSize: 18),
                                        )
                                      : CircularProgressIndicator(
                                          backgroundColor:
                                              Colors.white,
                                        ),
                                  onPressed: _submitForm,
                                )),
                            Padding(
                              padding: EdgeInsets.all(30),
                            ),
                          ],
                        )),
                      ),
                    ],
                  ),
                )));
  }
}