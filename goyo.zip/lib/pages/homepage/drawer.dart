import 'package:flutter/material.dart';
import 'package:flutter/widgets.dart';
import 'package:flutter_svg/flutter_svg.dart';
import './../../data/rest_ds.dart';
import './../../auth.dart';
import './../register/login.dart';
import './../../utils/template.dart' as template;

Widget get_drawer(BuildContext context) {
  var authStateProvider = new AuthStateProvider();
  RestDatasource api = new RestDatasource();
  return Drawer(
    child: ListView(
      children: <Widget>[
        Stack(
          children: <Widget>[
            DrawerHeader(
              child: Container(child: null),
              decoration: BoxDecoration(
                color: Color(0XFFF2F2F2),
              ),
            ),
            Container(
                padding: EdgeInsets.only(
                    top: MediaQuery.of(context).size.height / 12),
                alignment: Alignment.center,
                child: Container(
                  decoration: BoxDecoration(
                      borderRadius: BorderRadius.circular(
                          MediaQuery.of(context).size.width * 0.5),
                      color: Colors.red,
                      image: DecorationImage(
                          fit: BoxFit.cover,
                          image: NetworkImage(
                              'https://servicerabbit.pictuscode.com/images/site/profile/21.jpg'))),
                  width: MediaQuery.of(context).size.width * 0.5,
                  height: MediaQuery.of(context).size.width * 0.5,
                  child: null,
                )),
          ],
        ),
        Container(
          width: MediaQuery.of(context).size.width,
          /* padding:
              EdgeInsets.only(left: MediaQuery.of(context).size.width * 0.25),*/
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.center,
            mainAxisSize: MainAxisSize.max,
            mainAxisAlignment: MainAxisAlignment.end,
            children: <Widget>[
              Container(
                padding: EdgeInsets.only(top: 20, left: 10, right: 20),
                child: template.Textslimbold(
                          "Profile", 17, Color(0XFF4d4d4d)),
              ),
               Container(
                padding: EdgeInsets.only(top: 20, left: 10, right: 20),
                child:  template.Textslimbold(
                          "History", 17, Color(0XFF4d4d4d)),
              ),
              Container(
                padding: EdgeInsets.only(top: 20, left: 10, right: 20),
                child: template.Textslimbold(
                          "Settings", 17, Color(0XFF4d4d4d)),
              ),
              InkWell(
                child: Container(
                  width: MediaQuery.of(context).size.width,
                  alignment: Alignment.center,
                  padding:
                      EdgeInsets.only(top: 15, left: 10, right: 20, bottom: 15),
                  child:
                      template.Textslimbold(
                          "Signout", 17, Color(0XFF4d4d4d)),
                ),
                onTap: () {
                  authStateProvider.logout();

                  Navigator.pushAndRemoveUntil(
                      context,
                      MaterialPageRoute(builder: (context) => Loginpage()),
                      (e) => false);
                },
              )
            ],
          ),
        ),
        Container(
          child: Container(
            padding: EdgeInsets.only(top: 10, left: 60, right: 60, bottom: 20),
            alignment: Alignment.center,
            child: Image.asset("assets/images/logo.png"),
          ),
        )
      ],
    ),
  );
}
