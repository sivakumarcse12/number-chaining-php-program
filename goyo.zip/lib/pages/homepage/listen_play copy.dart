import 'package:flutter/material.dart';
import 'package:flutter/widgets.dart';
import 'package:flutter_svg/flutter_svg.dart';
import 'package:audioplayers/audioplayers.dart';
import 'package:goyogi/pages/homepage/welcome.dart';
import 'package:percent_indicator/percent_indicator.dart';
import 'dart:async';
import 'dart:io';
import 'dart:typed_data';
import 'package:path_provider/path_provider.dart';

typedef void OnError(Exception exception);

class ListenPlaypage extends StatefulWidget {
   String title;
  String description;
  String audio;
  String image;

  ListenPlaypage(this.title, this.description, this.audio, this.image);
  @override
  _StartPage createState() => new _StartPage();
}

class _StartPage extends State<ListenPlaypage> {
  Duration duration;
  Duration position;
  get durationText =>
      duration != null ? duration.toString().split('.').first : '';
  get positionText =>
      position != null ? position.toString().split('.').first : '';
  StreamSubscription _positionSubscription;
  StreamSubscription _audioPlayerStateSubscription;

  AudioPlayer audioPlayer = new AudioPlayer();
  bool _progressBarActive = false;
  Color initial_color = Colors.black;
  bool _playbutton1 = true;
  bool _playbutton2 = true;
  bool _playbutton3 = true;
  String current_seconds = "00:00";
  String max_seconds = "20:00";
  double maxSec = 0;
  double curSec = 0;
  double processper = 0;
  int current_play;
  int result;
  @override
  void initState() {
    // TODO: implement initState
    super.initState();
    audioPlayer.onPlayerCompletion.listen((event) {
      setState(() {
        initial_color = Colors.black;
        _playbutton1 = true;
        _playbutton2 = true;
        _playbutton3 = true;
      });
    });
    audioPlayer.onDurationChanged.listen((Duration d) {
      setState(() {
        duration = d;
      });
    });
    audioPlayer.onAudioPositionChanged.listen((Duration p) {
      setState(() {
        position = p;
      });
    });
  }

  load() async {
    audioPlayer.onPlayerCompletion.listen((event) {
      setState(() {
        initial_color = Colors.black;
        _playbutton1 = true;
        _playbutton2 = true;
        _playbutton3 = true;
      });
    });
  }

  seek(dur) async {
    print(dur);
    //int result1 = await audioPlayer.stop();
    int result = await audioPlayer.seek(Duration(milliseconds: dur.toInt()));
    setState(() {
      processper = dur.toDouble();
    });
  }

  @override
  void dispose() {
    super.dispose();
    this.stop();
  }

  play() async {
    if (_playbutton1 == false || _playbutton2 == false) {
      this.stop();
    } else {
      setState(() {
        if (current_play == 1) {
          _playbutton1 = false;
          _playbutton2 = true;
          _playbutton3 = true;
        } else if (current_play == 2) {
          _playbutton1 = true;
          _playbutton2 = false;
          _playbutton3 = true;
        } else if (current_play == 3) {
          _playbutton1 = true;
          _playbutton2 = true;
          _playbutton3 = false;
        }
        initial_color = Colors.red[400];
      });
      if (current_play == 3) {
        current_play = 1;
      }
      String url = widget.audio;
      result = await audioPlayer.play(url);
      if (result == 1) {
        setState(() {
          //initial_color=Colors.white;
        });
      }
    }

    //if(_playbutton==true){ stop();}
  }

  pause() async {
    int result = await audioPlayer.pause();
  }

  stop() async {
    int result = await audioPlayer.stop();
    setState(() {
      initial_color = Colors.black;
      _playbutton1 = true;
      _playbutton2 = true;
      _playbutton3 = true;
      //max_seconds="00:00";
      current_seconds = "00:00";
      maxSec = 0;
      curSec = 0;
      processper = 0;
       position = new Duration();
    });
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: Colors.white,
      body: SingleChildScrollView(
        child: Container(
            child: Column(
          children: <Widget>[
            Stack(
              children: <Widget>[
                Container(
                  padding: EdgeInsets.only(bottom: 60),
                  width: MediaQuery.of(context).size.width,
                  height: MediaQuery.of(context).size.height * 0.8,
                  decoration: BoxDecoration(
                      image: DecorationImage(
                          image: NetworkImage(widget.image),
                          fit: BoxFit.cover)),
                  alignment: Alignment.center,
                  child: null,
                ),
                Container(
                  alignment: Alignment.centerRight,
                  child: InkWell(
                    child: Container(
                        decoration: BoxDecoration(
                            color: Colors.black26, shape: BoxShape.circle),
                        width: 60,
                        height: 60,
                        child: Center(
                            child: Icon(
                          Icons.close,
                          color: Colors.white,
                          size: 30,
                        ))),
                    onTap: () {
                      this.stop();
                      Navigator.pop(context);
                    },
                  ),
                  padding: EdgeInsets.only(right: 20, top: 40),
                )
              ],
            ),
            Container(
              padding: EdgeInsets.only(top: 20, left: 10, right: 20),
              width: MediaQuery.of(context).size.width,
              child: Row(
                mainAxisAlignment: MainAxisAlignment.start,
                children: <Widget>[
                  Container(
                      alignment: Alignment.center,
                      padding: EdgeInsets.only(left: 0),
                      child: InkWell(
                        child: Container(
                          height: 80,
                          width: 80,
                          child: Center(
                              child: Icon(
                            _playbutton1 == true
                                ? Icons.play_arrow
                                : Icons.stop,
                            color: Theme.of(context).primaryColor,
                            size: 40,
                          )),
                          decoration: BoxDecoration(
                              color: Color(0XFFf7f6fc),
                              border: Border.all(color: Color(0XFFE1E1E1)),
                              borderRadius: BorderRadius.circular(40)),
                        ),
                        onTap: () {
                          setState(() {
                            current_play = 1;
                          });
                          this.play();
                        },
                      )),
                  Container(
                      padding: EdgeInsets.only(left: 10, right: 10),
                      child: Column(
                        crossAxisAlignment: CrossAxisAlignment.start,
                        children: <Widget>[
                          Container(
                              width: MediaQuery.of(context).size.width * 0.6,
                              child: Text(
                               widget.title==""? "GoYoga Level - 1":widget.title,
                                style: TextStyle(
                                    fontFamily: "Courgette",
                                    fontSize: 22,
                                    color: Color(0XFF4d4d4d)),
                              )),
                          Container(
                              padding: EdgeInsets.only(top: 5, bottom: 5),
                              child:
                                  /* LinearProgressIndicator(
                                semanticsLabel: "siva",
                                backgroundColor: Colors.grey,
                                valueColor: AlwaysStoppedAnimation<Color>(
                                  Theme.of(context).primaryColor,
                                ),
                                value: processper,
                              )
                                  LinearPercentIndicator(
                                width: MediaQuery.of(context).size.width * 0.6,
                                animation: false,
                                lineHeight: 10.0,
                                percent: processper,
                                linearStrokeCap: LinearStrokeCap.roundAll,
                                progressColor: Theme.of(context).primaryColor,
                              )
                              */
                                  null),
                          Container(
                            child: Container(
                                width: MediaQuery.of(context).size.width * 0.6,
                                child: duration == null
                                    ? new Container()
                                    : Slider(
                                        min: 0,
                                        max: duration.inMilliseconds.toDouble(),
                                        value: position?.inMilliseconds
                                                ?.toDouble() ??
                                            0.0,
                                        onChanged: (value) {
                                          audioPlayer.seek(Duration(
                                              seconds: (value ~/ 1000).toInt()));
                                        },
                                        activeColor: Theme.of(context)
                                            .primaryColor
                                            .withOpacity(.7),
                                        inactiveColor:
                                            Colors.grey.withOpacity(.2),
                                      )),
                          ),
                          Container(
                            width: MediaQuery.of(context).size.width * 0.6,
                            padding: EdgeInsets.only(top: 5),
                            alignment: Alignment.centerLeft,
                            child: Row(
                              mainAxisAlignment: MainAxisAlignment.spaceBetween,
                              children: <Widget>[
                                Container(
                                  child: Text(
                                    positionText == ""
                                        ? " "
                                        : positionText.toString(),
                                    style: TextStyle(
                                        fontFamily: "Courgette",
                                        fontSize: 12,
                                        color: Color(0XFF4d4d4d)),
                                  ),
                                ),
                                Container(
                                    child: Text(
                                  duration != null ? durationText : '',
                                  style: TextStyle(
                                      fontFamily: "Courgette",
                                      fontSize: 12,
                                      color: Color(0XFF4d4d4d)),
                                )),
                              ],
                            ),
                          ),
                        ],
                      ))
                ],
              ),
            ),
          ],
        )),
      ),
    );
  }
}
