import 'package:flutter/material.dart';
import 'package:flutter/widgets.dart';
import './listen.dart';
import 'package:flutter_svg/flutter_svg.dart';
import 'package:audioplayers/audioplayers.dart';
import './sidebar.dart';
import './drawer.dart';
import './../../data/rest_ds.dart';
import 'package:shimmer/shimmer.dart';
import './../register/login.dart';
import './profile.dart';
import './../../auth.dart';
import './play_history.dart';
import './change_password.dart';

import 'package:image_cropper/image_cropper.dart';
import 'package:image_picker/image_picker.dart';
import 'dart:io';
import 'dart:convert';
import 'package:cached_network_image/cached_network_image.dart';
import './../../utils/template.dart' as template;

var authStateProvider = new AuthStateProvider();
RestDatasource api = new RestDatasource();

class Homepage extends StatefulWidget {
  @override
  _StartPage createState() => new _StartPage();
}

class _StartPage extends State<Homepage> {
  List taskdata;
  bool InternetError = false;
  int taskpresent = 0;
  int taskperPage = 15;
  int tasksearch_status = 0;
  int task_loading = 0;
  bool img_loader = false;
  String task_time;
  String img = "http://icubesolutions.com/go-yogi/media/profile/default.png";
  bool enabled = false;
  var items = List<String>();
  RestDatasource api = new RestDatasource();
  ScrollController _favscrollController = new ScrollController();
  TextEditingController favsearchController = new TextEditingController();
  final GlobalKey<RefreshIndicatorState> _favrefreshIndicatorKey =
      new GlobalKey<RefreshIndicatorState>();
  final GlobalKey<FormState> _formKey = GlobalKey<FormState>();
  final scaffoldKey_active = new GlobalKey<ScaffoldState>();
  final timecontroller = TextEditingController();
  AudioPlayer audioPlayer = new AudioPlayer();
  bool _progressBarActive = false;
  Color initial_color = Colors.black;
  bool _playbutton1 = true;
  bool _playbutton2 = true;
  bool _playbutton3 = true;
  int current_play;
  int result;
  List audiobtn_list = new List();
  List audiobtn_spinner = new List();

  File file;
  File croppedFile;

  void _choose() async {
    //file = await ImagePicker.pickImage(source: ImageSource.camera);
    file = await ImagePicker.pickImage(source: ImageSource.gallery);
    //debugPrint(base64Encode(file.readAsBytesSync()));
    _cropImage(file);
  }

  Future _cropImage(File imageFile) async {
    croppedFile = await ImageCropper.cropImage(
      sourcePath: imageFile.path,
      maxWidth: 365,
      maxHeight: 441,
    );
    this.userImage(croppedFile);
  }

  get_user_info() {
    api.get_user_info().then((response) {
      print(response);
      setState(() {
        if (response["status"] == 1) {
          img = response["img"];
        }
      });
    });
  }

  @override
  userImage(File _image) {
    if (_image == null) return;
    String image = base64Encode(_image.readAsBytesSync());
    setState(() {
      img_loader = true;
      img = "http://icubesolutions.com/go-yogi/media/profile/default23.png";
    });
    api.image_upload_new('data:image/png;base64,' + image).then((response) {
      //this._showSnackBar(response['message']);
      this.get_user_info();
      setState(() {
        img_loader = false;
      });
    });
  }

  Widget get_drawer(BuildContext context, img) {
    var authStateProvider = new AuthStateProvider();
    RestDatasource api = new RestDatasource();

    return Drawer(
      child: ListView(
        children: <Widget>[
          Stack(
            children: <Widget>[
              DrawerHeader(
                child: Container(child: null),
                decoration: BoxDecoration(
                  color: Color(0XFFF2F2F2),
                ),
              ),
              Container(
                  padding: EdgeInsets.only(
                      top: MediaQuery.of(context).size.height / 12),
                  alignment: Alignment.center,
                  child: InkWell(
                      onTap: _choose,
                      splashColor:
                          Theme.of(context).primaryColor, // inkwell color
                      child: Container(
                        decoration: BoxDecoration(
                            borderRadius: BorderRadius.circular(
                                MediaQuery.of(context).size.width * 0.5),
                            color: Color(0XFFE1E1E1),
                            image: DecorationImage(
                                fit: BoxFit.cover,
                                image: CachedNetworkImageProvider(img == ""
                                    ? 'http://icubesolutions.com/go-yogi/media/profile/default.png'
                                    : img))),
                        width: MediaQuery.of(context).size.width * 0.5,
                        height: MediaQuery.of(context).size.width * 0.5,
                        child: img_loader == true
                            ? Container(
                                child: Center(
                                child: CircularProgressIndicator(
                                  backgroundColor:
                                      Theme.of(context).primaryColor,
                                ),
                              ))
                            : null,
                      ))),
            ],
          ),
          Container(
            width: MediaQuery.of(context).size.width,
            /* padding:
              EdgeInsets.only(left: MediaQuery.of(context).size.width * 0.25),*/
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.center,
              mainAxisSize: MainAxisSize.max,
              mainAxisAlignment: MainAxisAlignment.end,
              children: <Widget>[
                InkWell(
                    child: Container(
                      width: MediaQuery.of(context).size.width,
                      alignment: Alignment.center,
                      padding: EdgeInsets.only(
                          top: 20, left: 10, right: 20, bottom: 10),
                      child: template.Textslimbold(
                          "Profile", 17, Color(0XFF4d4d4d)),
                    ),
                    onTap: () {
                      Navigator.push(
                          context,
                          MaterialPageRoute(
                              builder: (context) => Profilepage()));
                    }),
                InkWell(
                    child: Container(
                      width: MediaQuery.of(context).size.width,
                      alignment: Alignment.center,
                      padding: EdgeInsets.only(
                          top: 10, left: 10, right: 20, bottom: 10),
                      child: template.Textslimbold(
                          "History", 17, Color(0XFF4d4d4d)),
                    ),
                    onTap: () {
                      Navigator.push(
                          context,
                          MaterialPageRoute(
                              builder: (context) => PlayHistory()));
                    }),
                InkWell(
                    child: Container(
                      width: MediaQuery.of(context).size.width,
                      alignment: Alignment.center,
                      padding: EdgeInsets.only(
                          top: 10, left: 10, right: 10, bottom: 10),
                      child: template.Textslimbold(
                          "Settings", 17, Color(0XFF4d4d4d)),
                    ),
                    onTap: () {
                      Navigator.push(
                          context,
                          MaterialPageRoute(
                              builder: (context) => Passwordpage()));
                    }),
                InkWell(
                    child: Container(
                      width: MediaQuery.of(context).size.width,
                      alignment: Alignment.center,
                      padding: EdgeInsets.only(
                          top: 15, left: 10, right: 20, bottom: 15),
                      child: template.Textslimbold(
                          "Signout", 17, Color(0XFF4d4d4d)),
                    ),
                    onTap: () {
                      LogoutDialog();
                    })
              ],
            ),
          ),
          Container(
            child: Container(
              padding:
                  EdgeInsets.only(top: 10, left: 60, right: 60, bottom: 20),
              alignment: Alignment.center,
              child: Image.asset("assets/images/logo.png"),
            ),
          )
        ],
      ),
    );
  }

  LogoutDialog() {
    return showDialog(
      context: context,
      barrierDismissible: false, // user must tap button for close dialog!
      builder: (BuildContext context) {
        return AlertDialog(
          title: Text('Are you sure?'),
          content: const Text('Do you really want to log out?'),
          actions: <Widget>[
            FlatButton(
              color: Colors.black,
              child: const Text('Cancel'),
              onPressed: () {
                Navigator.of(context).pop();
              },
            ),
            FlatButton(
              color: Colors.black,
              child: const Text('Ok'),
              onPressed: () {
                authStateProvider.logout();

                Navigator.pushAndRemoveUntil(
                    context,
                    MaterialPageRoute(builder: (context) => Loginpage()),
                    (e) => false);
              },
            )
          ],
        );
      },
    );
  }

  void _showSnackBar(String text) {
    scaffoldKey_active.currentState.showSnackBar(new SnackBar(
        content: new Text(
      text,
      style: TextStyle(
        fontFamily: "Montserrat",
      ),
    )));
  }

  @override
  void initState() {
    // TODO: implement initState
    super.initState();
    this.get_session_list(0);
    audioPlayer.onPlayerCompletion.listen((event) {
      setState(() {
        initial_color = Colors.black;
      });
    });
    _favscrollController.addListener(() {
      if (_favscrollController.position.pixels ==
          _favscrollController.position.maxScrollExtent) {
        loadMore();
      } else if (_favscrollController.position.pixels !=
          _favscrollController.position.maxScrollExtent) {
        setState(() {
          tasksearch_status = 0;
        });
      }
    });
    audioPlayer.onDurationChanged.listen((Duration d) {
      print("play");
      setState(() {
        audiobtn_spinner[current_play] = false;
      });
    });
    this.getImage();
  }

  getImage() async {
    String im = await api.get_userinfo("pro_pic");
    setState(() {
      img = im;
    });
  }

  load() async {
    audioPlayer.onPlayerCompletion.listen((event) {
      setState(() {
        initial_color = Colors.black;
        _playbutton1 = true;
        _playbutton2 = true;
        _playbutton3 = true;
      });
    });
  }

  get_session_list(count) {
    api.get_session_list(count).then((response) {
      setState(() {
        if (response["status"] == 1) {
          taskdata = response["audio_list"];
          for (int i = 0; i < response["audio_list"].length; i++) {
            audiobtn_list.add(true);
            audiobtn_spinner.add(false);
          }
        } else {
          taskdata = [];
          tasksearch_status = 1;
        }
      });
    });
  }

  get_session_list_ajax(count) {
    api.get_session_list(count).then((response) {
      setState(() {
        task_loading = 0;
        if (response["status"] == 1) {
          List tempList = new List();
          //data = response["user_list"];

          for (int i = 0; i < response["audio_list"].length; i++) {
            tempList.add(response['audio_list'][i]);
            audiobtn_list.add(true);
            audiobtn_spinner.add(false);
          }

          taskdata.addAll(tempList);
        } else {
          tasksearch_status = 1;
        }
      });
    });
  }

  void loadMore() {
    setState(() {
      taskpresent = taskpresent + 1;
      // print("hello");
      task_loading = 1;
      this.get_session_list_ajax(taskpresent);
      this.stop();
    });
  }

  Future<Null> _favrefresh() {
    taskdata = null;
    this.get_session_list(0);
    taskpresent = 0;

    setState(() {
      taskdata = null;
    });
  }

  @override
  void dispose() {
    super.dispose();
    _favscrollController.dispose();
    this.stop();
  }

  play(audio_file, i, audio_id) async {
    if (audiobtn_list.contains(false)) {
      this.stop();
    } else {
      setState(() {
        for (int j = 0; j < audiobtn_list.length; j++) {
          audiobtn_list[j] = true;
        }
        audiobtn_list[i] = false;
        audiobtn_spinner[current_play] = true;
        initial_color = Colors.red[400];
      });

      api.update_audio_played_log(audio_id);

      String url = audio_file;
      //print(audio_file);
      result = await audioPlayer.play(url);
      if (result == 1) {
        setState(() {
          //initial_color=Colors.white;
        });
      }
    }

    //if(_playbutton==true){ stop();}
  }

  pause() async {
    int result = await audioPlayer.pause();
  }

  stop() async {
    int result = await audioPlayer.stop();
    setState(() {
      initial_color = Colors.black;
      for (int j = 0; j < audiobtn_list.length; j++) {
        audiobtn_list[j] = true;
        audiobtn_spinner[j] = false;
      }
    });
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      drawer: get_drawer(context, img),
      key: scaffoldKey_active,
      backgroundColor: Colors.white,
      appBar: PreferredSize(
          preferredSize: Size.fromHeight(150.0), // here the desired height
          child: AppBar(
              leading: InkWell(
                child: Container(
                    padding: EdgeInsets.all(15),
                    width: 25,
                    child: SvgPicture.asset("assets/images/menu.svg")),
                onTap: () {
                  scaffoldKey_active.currentState.openDrawer();
                },
              ),
              title: template.Textslimbold("GoYogi", 18, Colors.white),
              backgroundColor: Theme.of(context).primaryColor,
              centerTitle: true,
              bottom: PreferredSize(
                preferredSize: const Size.fromHeight(50.0),
                child: Container(
                  padding: EdgeInsets.only(bottom: 20),
                  alignment: Alignment.center,
                  child: template.Textslimbold("MY CLASSES", 18, Colors.white),
                ),
              ))),
      body: taskdata == null
          ? Container(
              //color: Theme.of(context).primaryColor,

              child: Column(children: <Widget>[
              Expanded(
                child: Container(
                    color: Colors.white,
                    child: new SingleChildScrollView(
                        child: add_static(context, 4))),
              )
            ]))
          : Container(
              padding: EdgeInsets.only(
                  left: MediaQuery.of(context).size.width * 0.05,
                  right: MediaQuery.of(context).size.width * 0.05,
                  top: 10,
                  bottom: 20),
              child: Column(
                children: <Widget>[
                  Expanded(
                      child: RefreshIndicator(
                          onRefresh: _favrefresh,
                          child: new ListView.builder(
                              controller: _favscrollController,
                              itemCount: taskdata == null ? 0 : taskdata.length,
                              itemBuilder: (BuildContext context, i) {
                                return new InkWell(
                                    child: Container(
                                      padding:
                                          EdgeInsets.only(bottom: 20, top: 20),
                                      decoration: BoxDecoration(
                                          border: Border(
                                              bottom: BorderSide(
                                                  color: Colors.black))),
                                      child: Row(
                                        children: <Widget>[
                                          /*Container(
                                            child: Image.network(
                                                 taskdata[i]["image"]),
                                            width: MediaQuery.of(context)
                                                    .size
                                                    .width *
                                                0.2,
                                          ),*/
                                          Container(
                                              decoration: BoxDecoration(
                                                  color: Colors.black26,
                                                  image: DecorationImage(
                                                    image: new NetworkImage(
                                                        taskdata[i]
                                                            ["small_image"]),
                                                    fit: BoxFit.fill,
                                                  ),
                                                  borderRadius:
                                                      new BorderRadius.circular(
                                                          MediaQuery.of(context)
                                                                  .size
                                                                  .width *
                                                              0.1)),
                                              width: MediaQuery.of(context)
                                                      .size
                                                      .width *
                                                  0.2,
                                              height: MediaQuery.of(context)
                                                      .size
                                                      .width *
                                                  0.2,
                                              child: null),
                                          Container(
                                              padding:
                                                  EdgeInsets.only(left: 10),
                                              width: MediaQuery.of(context)
                                                      .size
                                                      .width *
                                                  0.5,
                                              child: Column(
                                                children: <Widget>[
                                                  Container(
                                                      width:
                                                          MediaQuery.of(context)
                                                                  .size
                                                                  .width *
                                                              0.5,
                                                      child: template.Textslimbold(
                                                          taskdata[i]["title"] ==
                                                                  ""
                                                              ? "-"
                                                              : taskdata[i]
                                                                  ["title"],
                                                          15,
                                                          Color(0XFF4d4d4d))),
                                                  Container(
                                                    width:
                                                        MediaQuery.of(context)
                                                                .size
                                                                .width *
                                                            0.5,
                                                    padding:
                                                        EdgeInsets.only(top: 5),
                                                    alignment:
                                                        Alignment.centerLeft,
                                                    child: Row(
                                                      mainAxisAlignment:
                                                          MainAxisAlignment
                                                              .start,
                                                      children: <Widget>[
                                                        /*Container(
                                                          child: Icon(
                                                            Icons.access_time,
                                                            size: 15,
                                                          ),
                                                        ),*/
                                                        Container(
                                                            margin:
                                                                EdgeInsets.only(
                                                                    left: 5),
                                                            child: template.Textregular(
                                                                taskdata[i]["duration"] !=
                                                                        ""
                                                                    ? taskdata[
                                                                            i][
                                                                        "duration"]
                                                                    : "10 Mins",
                                                                15,
                                                                Color(
                                                                    0XFF4d4d4d))),
                                                      ],
                                                    ),
                                                  ),
                                                ],
                                              )),
                                          Container(
                                              alignment: Alignment.center,
                                              padding:
                                                  EdgeInsets.only(left: 20),
                                              child: InkWell(
                                                child: Container(
                                                  height: 50,
                                                  width: 50,
                                                  child: Center(
                                                      child: audiobtn_spinner[
                                                                  i] ==
                                                              false
                                                          ? Icon(
                                                              audiobtn_list[
                                                                          i] ==
                                                                      true
                                                                  ? Icons
                                                                      .play_arrow
                                                                  : Icons.stop,
                                                              color: Theme.of(
                                                                      context)
                                                                  .primaryColor,
                                                              size: 30,
                                                            )
                                                          : CircularProgressIndicator(
                                                              backgroundColor:
                                                                  Theme.of(
                                                                          context)
                                                                      .primaryColor,
                                                            )),
                                                  decoration: BoxDecoration(
                                                      color: Color(0XFFf7f6fc),
                                                      border: Border.all(
                                                          color: Color(
                                                              0XFFE1E1E1)),
                                                      borderRadius:
                                                          BorderRadius.circular(
                                                              25)),
                                                ),
                                                onTap: () {
                                                  setState(() {
                                                    current_play = i;
                                                  });
                                                  this.play(
                                                      taskdata[i]["audio_file"],
                                                      i,
                                                      taskdata[i]["id"]);
                                                },
                                              ))
                                        ],
                                      ),
                                    ),
                                    onTap: () {
                                      this.stop();
                                      Navigator.push(
                                          context,
                                          MaterialPageRoute(
                                              builder: (context) => Listenpage(
                                                  taskdata[i]["title"],
                                                  taskdata[i]["description"],
                                                  taskdata[i]["audio_file"],
                                                  taskdata[i]["image"],
                                                  taskdata[i]["small_image"],
                                                  taskdata[i]["id"],
                                                  taskdata[i]["duration"])));
                                    });
                              }))),
                  task_loading == 1
                      ? Container(padding: EdgeInsets.all(10),
                          color: Colors.white,
                          child: new Center(
                              child: CircularProgressIndicator(
                                  backgroundColor:
                                      Theme.of(context).primaryColor)))
                      : Container(
                          child: null,
                        ),
                  tasksearch_status == 1
                      ? Container(
                          alignment: Alignment.center,
                          width: MediaQuery.of(context).size.width,
                          padding: EdgeInsets.all(10),
                          color: Theme.of(context).primaryColor,
                          child: template.Textregular(
                              "No more class found.", 14, Colors.white))
                      : Container(
                          child: null,
                        )
                ],
              ),
            ),
    );
  }

  Widget add_static(context, int itemcount) {
    Color common_shimmingcolor = Colors.grey[200];
    List<Widget> list = new List<Widget>();
    for (var i = 0; i < itemcount - 2; i++) {
      list.add(Container(
          decoration: new BoxDecoration(
              boxShadow: [
                new BoxShadow(
                  color: Colors.white,
                  blurRadius: 20.0,
                ),
              ],
              border: Border(
                bottom: BorderSide(
                  //                    <--- top side
                  color: Color(0XFFededed),
                  width: 10.0,
                ),
              )),
          padding: EdgeInsets.only(left: 10, top: 10, right: 10),
          child: Column(
            children: <Widget>[
              Container(
                  width: MediaQuery.of(context).size.width,
                  decoration: new BoxDecoration(
                      border: Border(
                    bottom: BorderSide(
                      //                    <--- top side
                      color: Color(0XFFededed),
                      width: 1.0,
                    ),
                  )),
                  padding: EdgeInsets.all(10),
                  child: Row(
                    children: <Widget>[
                      Shimmer.fromColors(
                          baseColor: common_shimmingcolor,
                          highlightColor: Colors.white,
                          child: Container(
                              decoration: BoxDecoration(
                                  color: common_shimmingcolor,
                                  borderRadius:
                                      new BorderRadius.circular(25.0)),
                              width: 50,
                              height: 50,
                              child: null)),
                      Container(
                          width: MediaQuery.of(context).size.width * 0.60,
                          padding: EdgeInsets.only(left: 10),
                          child: Column(
                            crossAxisAlignment: CrossAxisAlignment.start,
                            children: <Widget>[
                              Row(
                                mainAxisAlignment:
                                    MainAxisAlignment.spaceBetween,
                                children: <Widget>[
                                  Shimmer.fromColors(
                                      baseColor: common_shimmingcolor,
                                      highlightColor: Colors.white,
                                      child: Container(
                                        width:
                                            MediaQuery.of(context).size.width *
                                                0.30,
                                        height: 10,
                                        decoration: BoxDecoration(
                                            color: common_shimmingcolor,
                                            borderRadius:
                                                BorderRadius.circular(10)),
                                        child: null,
                                      )),
                                  Container(
                                      child: Row(
                                    children: <Widget>[
                                      Padding(
                                        padding: EdgeInsets.only(left: 5),
                                      ),
                                      Shimmer.fromColors(
                                          baseColor: common_shimmingcolor,
                                          highlightColor: Colors.white,
                                          child: Container(
                                            decoration: BoxDecoration(
                                                color: common_shimmingcolor,
                                                borderRadius:
                                                    BorderRadius.circular(10)),
                                            width: MediaQuery.of(context)
                                                    .size
                                                    .width *
                                                0.10,
                                            height: 10,
                                            child: null,
                                          ))
                                    ],
                                  )),
                                ],
                              ),
                              Padding(
                                padding: EdgeInsets.only(top: 5),
                              ),
                              Shimmer.fromColors(
                                  baseColor: common_shimmingcolor,
                                  highlightColor: Colors.white,
                                  child: Container(
                                    decoration: BoxDecoration(
                                        color: common_shimmingcolor,
                                        borderRadius:
                                            BorderRadius.circular(10)),
                                    width: MediaQuery.of(context).size.width *
                                        0.30,
                                    height: 10,
                                    child: null,
                                  ))
                            ],
                          ))
                    ],
                  )),
            ],
          )));
    }
    return new Column(children: list);
  }
}
