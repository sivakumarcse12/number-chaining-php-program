import 'package:flutter/material.dart';
import 'package:flutter/widgets.dart';
import 'package:flutter_svg/flutter_svg.dart';
import 'package:audioplayers/audioplayers.dart';
import './homepage.dart';
import './../register/signup.dart';
import './../register/signup_individual.dart';

class Welcome extends StatefulWidget {
  @override
  _StartPage createState() => new _StartPage();
}

class _StartPage extends State<Welcome> {
  @override
  void initState() {
    // TODO: implement initState
    super.initState();
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: Colors.white,
      appBar: AppBar(
       
        title: Text(
          "GoYogi",
          style: TextStyle(
              fontFamily: "MontserratBold", fontSize: 18, color: Colors.white),
        ),
        backgroundColor: Theme.of(context).primaryColor,
        centerTitle: true,
      ),
      body: SingleChildScrollView(
        child: Container(
          padding: EdgeInsets.only(
              left:0,
              right: 0,
              top: 10,
              bottom: 20),
          child: Column(
            children: <Widget>[
              Container(
                padding:
                    EdgeInsets.only(top: 20, left: 0, right: 0, bottom: 30),
                child: Image.asset("assets/images/home-image.png"),
              ),
              /*Container(
                  alignment: Alignment.center,
                  child: Text(
                    "Pick One",
                    style: TextStyle(
                        fontFamily: "Courgette",
                        fontSize: 30,
                        color: Color(0XFF4d4d4d)),
                  )),*/
             
              SizedBox(
                height: 20.0,
              ),
              Container(
                  height: 60,
                  width: MediaQuery.of(context).size.width * 0.8,
                  child: RaisedButton(
                    color: Theme.of(context).primaryColor,
                    shape: new RoundedRectangleBorder(
                        borderRadius: new BorderRadius.circular(35.0)),
                    textColor: Colors.white,
                    child: Text(
                      'JOIN A GROUP',
                      style: TextStyle(
                          fontWeight: FontWeight.bold,
                          fontFamily: "MontserratBold",
                          color: Colors.white,
                          fontSize: 18),
                    ),
                    onPressed: () {
                      Navigator.push(context,
                          MaterialPageRoute(builder: (context) => Signuppage()));
                    },
                  )),
              SizedBox(
                height: 20.0,
              ),
              Container(
                  height: 60,
                  width: MediaQuery.of(context).size.width * 0.8,
                  child: RaisedButton(
                    color: Theme.of(context).primaryColor,
                    shape: new RoundedRectangleBorder(
                        borderRadius: new BorderRadius.circular(35.0)),
                    textColor: Colors.white,
                    child: Text(
                      'INDIVIDUAL',
                      style: TextStyle(
                          fontWeight: FontWeight.bold,
                          fontFamily: "MontserratBold",
                          color: Colors.white,
                          fontSize: 18),
                    ),
                    onPressed: () {
                      Navigator.push(context,
                          MaterialPageRoute(builder: (context) => Signupindividual()));
                    },
                  )),
              SizedBox(
                height: 40.0,
              ),
            ],
          ),
        ),
      ),
    );
  }
}
