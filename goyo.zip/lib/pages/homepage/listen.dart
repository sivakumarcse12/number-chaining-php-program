import 'package:flutter/material.dart';
import 'package:flutter/widgets.dart';
import 'package:flutter_svg/flutter_svg.dart';
import 'package:audioplayers/audioplayers.dart';
import './listen_play.dart';
import './sidebar.dart';
import './../../data/rest_ds.dart';
import 'package:shimmer/shimmer.dart';
import './../register/login.dart';
import './profile.dart';
import './../../auth.dart';
import './play_history.dart';
import './change_password.dart';

import 'package:image_cropper/image_cropper.dart';
import 'package:image_picker/image_picker.dart';
import 'dart:io';
import 'dart:convert';
import 'package:cached_network_image/cached_network_image.dart';
import './../../utils/template.dart' as template;

class Listenpage extends StatefulWidget {
  String title;
  String description;
  String audio;
  String image;
  String small_image;
  String id;
  String duration;

  Listenpage(this.title, this.description, this.audio, this.image,
      this.small_image, this.id, this.duration);
  @override
  _StartPage createState() => new _StartPage();
}

class _StartPage extends State<Listenpage> {
  String img = "https://figy.in/go-yogi/media/profile/default.png";
  File file;
  File croppedFile;
  RestDatasource api = new RestDatasource();
  void _choose() async {
    //file = await ImagePicker.pickImage(source: ImageSource.camera);
    file = await ImagePicker.pickImage(source: ImageSource.gallery);
    //debugPrint(base64Encode(file.readAsBytesSync()));
    _cropImage(file);
  }

  Future _cropImage(File imageFile) async {
    croppedFile = await ImageCropper.cropImage(
      sourcePath: imageFile.path,
      maxWidth: 365,
      maxHeight: 441,
    );
    this.userImage(croppedFile);
  }

  get_user_info() {
    api.get_user_info().then((response) {
      print(response);
      setState(() {
        if (response["status"] == 1) {
          img = response["img"];
        }
      });
    });
  }

  @override
  userImage(File _image) {
    if (_image == null) return;
    String image = base64Encode(_image.readAsBytesSync());
    debugPrint(image);
    api.image_upload_new('data:image/png;base64,' + image).then((response) {
      //this._showSnackBar(response['message']);
      this.get_user_info();
    });
  }

  Widget get_drawer(BuildContext context, img) {
    var authStateProvider = new AuthStateProvider();
    RestDatasource api = new RestDatasource();

    return Drawer(
      child: ListView(
        children: <Widget>[
          Stack(
            children: <Widget>[
              DrawerHeader(
                child: Container(child: null),
                decoration: BoxDecoration(
                  color: Color(0XFFF2F2F2),
                ),
              ),
              Container(
                  padding: EdgeInsets.only(
                      top: MediaQuery.of(context).size.height / 12),
                  alignment: Alignment.center,
                  child: InkWell(
                      onTap: _choose,
                      splashColor:
                          Theme.of(context).primaryColor, // inkwell color
                      child: Container(
                        decoration: BoxDecoration(
                            borderRadius: BorderRadius.circular(
                                MediaQuery.of(context).size.width * 0.5),
                            color: Color(0XFFE1E1E1),
                            image: DecorationImage(
                                fit: BoxFit.cover,
                                image: CachedNetworkImageProvider(img == ""
                                    ? 'http://icubesolutions.com/go-yogi/media/profile/default.png'
                                    : img))),
                        width: MediaQuery.of(context).size.width * 0.5,
                        height: MediaQuery.of(context).size.width * 0.5,
                        child: null,
                      ))),
            ],
          ),
          Container(
            width: MediaQuery.of(context).size.width,
            /* padding:
              EdgeInsets.only(left: MediaQuery.of(context).size.width * 0.25),*/
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.center,
              mainAxisSize: MainAxisSize.max,
              mainAxisAlignment: MainAxisAlignment.end,
              children: <Widget>[
                InkWell(
                    child: Container(
                      width: MediaQuery.of(context).size.width,
                      alignment: Alignment.center,
                      padding: EdgeInsets.only(
                          top: 20, left: 10, right: 20, bottom: 10),
                      child: template.Textslimbold(
                          "Profile", 17, Color(0XFF4d4d4d)),
                    ),
                    onTap: () {
                      Navigator.push(
                          context,
                          MaterialPageRoute(
                              builder: (context) => Profilepage()));
                    }),
                InkWell(
                    child: Container(
                      width: MediaQuery.of(context).size.width,
                      alignment: Alignment.center,
                      padding: EdgeInsets.only(
                          top: 10, left: 10, right: 20, bottom: 10),
                      child: template.Textslimbold(
                          "History", 17, Color(0XFF4d4d4d)),
                    ),
                    onTap: () {
                      Navigator.push(
                          context,
                          MaterialPageRoute(
                              builder: (context) => PlayHistory()));
                    }),
                InkWell(
                    child: Container(
                      width: MediaQuery.of(context).size.width,
                      alignment: Alignment.center,
                      padding: EdgeInsets.only(
                          top: 10, left: 10, right: 10, bottom: 10),
                      child: template.Textslimbold(
                          "Settings", 17, Color(0XFF4d4d4d)),
                    ),
                    onTap: () {
                      Navigator.push(
                          context,
                          MaterialPageRoute(
                              builder: (context) => Passwordpage()));
                    }),
                InkWell(
                  child: Container(
                    width: MediaQuery.of(context).size.width,
                    alignment: Alignment.center,
                    padding: EdgeInsets.only(
                        top: 15, left: 10, right: 20, bottom: 15),
                    child:
                        template.Textslimbold("Signout", 17, Color(0XFF4d4d4d)),
                  ),
                  onTap: () {
                    authStateProvider.logout();

                    Navigator.pushAndRemoveUntil(
                        context,
                        MaterialPageRoute(builder: (context) => Loginpage()),
                        (e) => false);
                  },
                )
              ],
            ),
          ),
          Container(
            child: Container(
              padding:
                  EdgeInsets.only(top: 10, left: 60, right: 60, bottom: 20),
              alignment: Alignment.center,
              child: Image.asset("assets/images/logo.png"),
            ),
          )
        ],
      ),
    );
  }

  getImage() async {
    String im = await api.get_userinfo("pro_pic");
    setState(() {
      img = im;
    });
  }

  @override
  void initState() {
    // TODO: implement initState
    super.initState();
    this.getImage();
  }

  @override
  void dispose() {
    super.dispose();
  }

  final scaffoldKey_active = new GlobalKey<ScaffoldState>();
  @override
  Widget build(BuildContext context) {
    return Scaffold(
    //  drawer: get_drawer(context, img),
      key: scaffoldKey_active,
      appBar: AppBar(
        elevation: 0,
        title: template.Textslimbold("GoYogi", 18, Colors.white),
        backgroundColor: Theme.of(context).primaryColor,
        centerTitle: true,
      ),
      backgroundColor: Colors.white,
      body: SingleChildScrollView(
        child: Container(
            padding: EdgeInsets.only(bottom: 20),
            child: Column(
              children: <Widget>[
                Stack(
                  children: <Widget>[
                    Container(
                      width: MediaQuery.of(context).size.width,
                      height: MediaQuery.of(context).size.height / 8,
                      child: Container(
                        decoration: BoxDecoration(
                            color: Colors.white,
                            border: Border.all(color: Colors.white, width: 5),
                            borderRadius: BorderRadius.only(
                                topLeft: Radius.circular(50),
                                topRight: Radius.circular(50))),
                        width: MediaQuery.of(context).size.width,
                        margin: EdgeInsets.only(
                            left: MediaQuery.of(context).size.width * 0.1,
                            right: MediaQuery.of(context).size.width * 0.1,
                            top: MediaQuery.of(context).size.height / 15),
                      ),
                      decoration:
                          BoxDecoration(color: Theme.of(context).primaryColor),
                    ),
                    /*Container(
                  width: MediaQuery.of(context).size.width,
                  alignment: Alignment.center,
                  child: Image.network(widget.image),
                  padding: EdgeInsets.only(
                      top: MediaQuery.of(context).size.height / 35),
                ),*/
                    Container(
                        width: MediaQuery.of(context).size.width,
                        alignment: Alignment.center,
                        child: Container(
                            padding: EdgeInsets.only(
                                top: MediaQuery.of(context).size.height / 35),
                            alignment: Alignment.centerLeft,
                            decoration: BoxDecoration(
                                color: Colors.black26,
                                image: DecorationImage(
                                  image: new NetworkImage(widget.small_image),
                                  fit: BoxFit.fill,
                                ),
                                borderRadius: new BorderRadius.circular(
                                    MediaQuery.of(context).size.width * 0.25)),
                            width: MediaQuery.of(context).size.width * 0.5,
                            height: MediaQuery.of(context).size.width * 0.5,
                            child: null))
                  ],
                ),
                Container(
                  padding: EdgeInsets.only(top: 20, left: 40, right: 20),
                  width: MediaQuery.of(context).size.width,
                  child: template.Textslimbold(
                      widget.title == "" ? "Goyogi Class - 1" : widget.title,
                      22,
                      Color(0XFF4d4d4d)),
                ),
                Container(
                  padding: EdgeInsets.only(top: 10, left: 40, right: 20),
                  width: MediaQuery.of(context).size.width,
                  child: template.Textslimbold(
                      "In this session you will learn ", 17, Colors.grey),
                ),
                Container(
                  padding: EdgeInsets.only(left: 40, top: 10),
                  child: Column(
                    children: <Widget>[
                      Container(
                          child: Row(
                        children: <Widget>[
                         
                          Container(
                            padding: EdgeInsets.only(left: 0, right: 20),
                            width: MediaQuery.of(context).size.width * 0.75,
                            child: template.Textregular(
                                widget.description, 15, Colors.grey),
                          ),
                        ],
                      )),
                      /*Container(
                          child: Row(
                        children: <Widget>[
                          Container(
                            height: 15.0,
                            width: 15.0,
                            decoration: BoxDecoration(
                                shape: BoxShape.circle,
                                color: Color(0XFF4d4d4d)),
                          ),
                          Container(
                            padding: EdgeInsets.only(left: 10, right: 20),
                            width: MediaQuery.of(context).size.width * 0.75,
                            child: Text(
                              "How to bend your shoulder",
                              style: TextStyle(
                                  fontFamily: "Courgette",
                                  fontSize: 20,
                                  color: Colors.grey),
                            ),
                          ),
                        ],
                      )),
                      Container(
                          child: Row(
                        children: <Widget>[
                          Container(
                            height: 15.0,
                            width: 15.0,
                            decoration: BoxDecoration(
                                shape: BoxShape.circle,
                                color: Color(0XFF4d4d4d)),
                          ),
                          Container(
                            padding: EdgeInsets.only(left: 10, right: 20),
                            width: MediaQuery.of(context).size.width * 0.75,
                            child: Text(
                              "Breathing Practice",
                              style: TextStyle(
                                  fontFamily: "Courgette",
                                  fontSize: 20,
                                  color: Colors.grey),
                            ),
                          ),
                        ],
                      )),
                      Container(
                          child: Row(
                        children: <Widget>[
                          Container(
                            height: 15.0,
                            width: 15.0,
                            decoration: BoxDecoration(
                                shape: BoxShape.circle,
                                color: Color(0XFF4d4d4d)),
                          ),
                          Container(
                            padding: EdgeInsets.only(left: 10, right: 20),
                            width: MediaQuery.of(context).size.width * 0.75,
                            child: Text(
                              "Pranayama basic ",
                              style: TextStyle(
                                  fontFamily: "Courgette",
                                  fontSize: 20,
                                  color: Colors.grey),
                            ),
                          ),
                        ],
                      )),*/
                    ],
                  ),
                ),
                Container(
                  width: MediaQuery.of(context).size.width,
                  padding: EdgeInsets.only(top: 10, left: 40),
                  alignment: Alignment.centerLeft,
                  child: Row(
                    mainAxisAlignment: MainAxisAlignment.start,
                    children: <Widget>[
                      Container(
                        child: Icon(
                          Icons.access_time,
                          size: 15,
                        ),
                      ),
                      Container(
                        margin: EdgeInsets.only(left: 7),
                        child: template.Textregular(
                            widget.duration, 13, Color(0XFF4d4d4d)),
                      ),
                    ],
                  ),
                ),
                SizedBox(
                  height: 30.0,
                ),
                Container(
                    height: 60,
                    width: MediaQuery.of(context).size.width * 0.8,
                    child: RaisedButton(
                      color: Theme.of(context).primaryColor,
                      shape: new RoundedRectangleBorder(
                          borderRadius: new BorderRadius.circular(35.0)),
                      textColor: Colors.white,
                      child: template.Textslimbold('LISTEN', 22, Colors.white),
                      onPressed: () {
                        Navigator.push(
                            context,
                            MaterialPageRoute(
                                builder: (context) => ListenPlaypage(
                                    widget.title,
                                    widget.description,
                                    widget.audio,
                                    widget.image,
                                    widget.id)));
                      },
                    )),
              ],
            )),
      ),
    );
  }
}
