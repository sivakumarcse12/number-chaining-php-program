import 'package:flutter/material.dart';
import 'package:flutter/widgets.dart';
import './../../data/rest_ds.dart';
import 'package:shared_preferences/shared_preferences.dart';


class Passwordpage extends StatefulWidget {
  @override
  _PasswordpagePageState createState() => new _PasswordpagePageState();
}

class _PasswordpagePageState extends State<Passwordpage> {
final GlobalKey<FormState> _formKey = GlobalKey<FormState>();
final scaffoldKey = new GlobalKey<ScaffoldState>();
  final formKey = new GlobalKey<FormState>();
  RestDatasource api = new RestDatasource();
  final Map<String, dynamic> _formData = {
    'current_password': null,
    'new_password': null,
    'repeat_password': null
  };
  bool _autoValidate = false;
  bool _isLoading=false;
  String new_password="";
  

  @override
  Widget build(BuildContext context) {
    return new Scaffold(key: scaffoldKey,
        appBar: new AppBar(centerTitle: true,
            title: Text("Change password",style: TextStyle(fontFamily: "MontserratBold",fontSize: 18),),
            // backgroundColor: Color(0xFF862828),
            flexibleSpace:
                Container(padding: EdgeInsets.only(top: 20), child: null)),
        body: Container(
            
            child: Container(
                color:Colors.white,
               
                child: Container(padding: EdgeInsets.only(left:20),
                  child: Form(autovalidate: _autoValidate,
                    key: _formKey,child:Container(child:SingleChildScrollView(child: Column(
                    children: <Widget>[
                      Padding(padding: EdgeInsets.all(10),),
                      Container(child: _buildoldpasswordTextField(),),
                      SizedBox(height: 20,),
                      Container(child: _buildnewpasswordTextField(),),
                       SizedBox(height: 20,),
                      Container(child: _buildrepeatpasswordTextField(),),
                       SizedBox(height: 40,),
                     
                     
                        Container(padding: EdgeInsets.only(right: 20),
                                height: 60,
                                width: MediaQuery.of(context).size.width * 0.8,
                                child: RaisedButton(
                                  color: Theme.of(context).primaryColor,
                                  shape: new RoundedRectangleBorder(
                                      borderRadius:
                                          new BorderRadius.circular(35.0)),
                                  textColor: Colors.white,
                                  child: _isLoading == false
                                      ? Text(
                                          'Save',
                                          style: TextStyle(
                                              fontWeight: FontWeight.bold,
                                              color: Colors.white,
                                              fontSize: 18,fontFamily: "MontserratBold",),
                                        )
                                      : CircularProgressIndicator(
                                          backgroundColor:
                                              Colors.white,
                                        ),
                                  onPressed: _submitForm,
                                )), 
                                 SizedBox(height: 340,),
                    ],
                  ))))),
                )));
  }
  void _showSnackBar(String text) {
    scaffoldKey.currentState
        .showSnackBar(new SnackBar(content: new Text(text)));
  }

  void _submitForm() {
    _formKey.currentState.validate();
    final form = _formKey.currentState;

    if (form.validate()) {
      setState(() {
        _isLoading = true;
      });
      _formKey.currentState.save();
     api.change_password(_formData['current_password'],_formData['new_password']).then((response) {
     print(response);
      setState(() {
         _isLoading = false; 
        if (response["status"] == 1) {  
         
          _formKey.currentState.reset();
          this._showSnackBar(response["message"]);
          
        
        } else {
         this._showSnackBar(response["message"]);
        }
      });
    });
    }
  }
  Widget _buildoldpasswordTextField() {
    return TextFormField(
      style: TextStyle(
        color: Colors.black,fontFamily: "Montserrat",
      ),
      decoration: InputDecoration(
          enabledBorder: UnderlineInputBorder(
            borderSide: BorderSide(
                color: Color(0XFFc5c5c5), width: 1.0, style: BorderStyle.solid),
          ),
          focusedBorder:
              UnderlineInputBorder(borderSide: BorderSide(color: Theme.of(context).primaryColor)),
          border: new UnderlineInputBorder(
              borderSide: new BorderSide(color: Color(0XFFc5c5c5))),
          labelStyle: new TextStyle(color: Color(0XFFc5c5c5),fontFamily: "Montserrat",),
          labelText: 'Current Password',
          filled: true,
          fillColor: Colors.white),obscureText: true,
     validator: (String value) {
        if (value.isEmpty ) {
          return 'Enter current password';
        }
      },
      onSaved: (String value) {
        _formData['current_password'] = value;
      },
    );
  }

  Widget _buildnewpasswordTextField() {
    return TextFormField(keyboardType: TextInputType.emailAddress, 
      style: TextStyle(
        color: Colors.black,fontFamily: "Montserrat",
      ),
       decoration: InputDecoration(
          enabledBorder: UnderlineInputBorder(
            borderSide: BorderSide(
                color: Color(0XFFc5c5c5), width: 1.0, style: BorderStyle.solid),
          ),
          focusedBorder:
              UnderlineInputBorder(borderSide: BorderSide(color: Theme.of(context).primaryColor)),
          border: new UnderlineInputBorder(
              borderSide: new BorderSide(color: Color(0XFFc5c5c5))),
          labelStyle: new TextStyle(color: Color(0XFFc5c5c5),fontFamily: "Montserrat",),
          labelText: 'New Password',
          
          filled: true,
          fillColor: Colors.white),obscureText: true,
      validator: (String value) {
       if (value.isEmpty ) {
          return 'Enter new password';
        }
       
       
        
      },
      onSaved: (String value) {
        _formData['new_password'] = value;
        setState(() {
         new_password=value; 
        });
      },
    );
  }
  Widget _buildrepeatpasswordTextField() {
    return TextFormField(keyboardType: TextInputType.emailAddress,
      style: TextStyle(
        color: Colors.black,fontFamily: "Montserrat",
      ),
      decoration: InputDecoration(
          enabledBorder: UnderlineInputBorder(
            borderSide: BorderSide(
                color: Color(0XFFc5c5c5), width: 1.0, style: BorderStyle.solid),
          ),
          focusedBorder:
              UnderlineInputBorder(borderSide: BorderSide(color: Theme.of(context).primaryColor)),
          border: new UnderlineInputBorder(
              borderSide: new BorderSide(color: Color(0XFFc5c5c5))),
          labelStyle: new TextStyle(color: Color(0XFFc5c5c5),fontFamily: "Montserrat",),
          labelText: 'Re enter new password',
          filled: true,
          fillColor: Colors.white),obscureText: true,
      validator: (String value) {  _formKey.currentState.save(); //print(_formData['new_password']);
        if (value.isEmpty ) {
          return 'Enter enter new password';
        }
         else if(value!=new_password){
          return 'Re-enter new password is wrong';
        }
      },
      
      onSaved: (String value) {
        _formData['repeat_password'] = value;
      },
    );
  }
 
}