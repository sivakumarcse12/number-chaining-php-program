import 'package:flutter/material.dart';
import 'package:flutter/widgets.dart';
import 'package:flutter_svg/flutter_svg.dart';

class StartPage1 extends StatefulWidget {
  @override
  _StartPage createState() => new _StartPage();
}

class _StartPage extends State<StartPage1> with TickerProviderStateMixin{
  @override
  void initState() {
    // TODO: implement initState
    super.initState();
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: Theme.of(context).primaryColor,
      body: SingleChildScrollView(
        child: Container(
          padding: EdgeInsets.only(
              left: MediaQuery.of(context).size.width * 0.05,
              right: MediaQuery.of(context).size.width * 0.05,
              top: MediaQuery.of(context).size.height / 9),
          child: Column(
            children: <Widget>[
              Container(
                child: SvgPicture.asset("assets/images/start1.svg"),
              ),
              Container(
                padding: EdgeInsets.only(top: 10),
                child: Text(
                  "Welcome",
                  style: TextStyle(
                      fontFamily: "Montserratel",
                      fontSize: 35,
                      color: Colors.white),
                ),
              ),
              Container(
                padding: EdgeInsets.only(top: 60,left: 40,right:40),
                child: Text(
                  "A Step to healthy life with GoYogi",
                  style: TextStyle(color: Colors.white,fontFamily: "Montserratel",fontSize: 22,),textAlign: TextAlign.center,
                ),
              )
            ],
          ),
        ),
      ),
    );
  }
}
