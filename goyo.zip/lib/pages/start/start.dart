import 'package:flutter/material.dart';
import 'package:flutter_svg/flutter_svg.dart';
import 'package:intro_views_flutter/Models/page_view_model.dart';
import 'package:intro_views_flutter/intro_views_flutter.dart';
import './../homepage/homepage.dart';
import './../homepage/welcome.dart';
import './../register/login.dart';
import './../../auth.dart';
import './../../data/rest_ds.dart';
import './../../data/database_helper.dart';

class StartPage extends StatefulWidget {
  @override
  _MyHomePageState createState() => new _MyHomePageState();
}

class _MyHomePageState extends State<StartPage> implements AuthStateListener {
  RestDatasource api = new RestDatasource();
  BuildContext _ctx;
  bool login_check = true;
  @override
  onAuthStateChanged(AuthState state) {
    //print(state);
    if (state == AuthState.LOGGED_IN) {
      setState(() {
        login_check = true;
      });
      Navigator.pushAndRemoveUntil(context,
          MaterialPageRoute(builder: (context) => Homepage()), (e) => false);
    } else {
      setState(() {
        login_check = false;
      });
    }
  }

  @override
  void initState() {
    // TODO: implement initState
    super.initState();
    var authStateProvider = new AuthStateProvider();
    authStateProvider.subscribe(this);
    // this.get_info();
  }

  get_info() async {
    String email = await api.get_userinfo("email");

    if (email != "") {
      Navigator.pushAndRemoveUntil(context,
          MaterialPageRoute(builder: (context) => Homepage()), (e) => false);
    }
  }

  final pages = [
    /*PageViewModel(
        pageColor: Colors.white, 
        bubble: SvgPicture.asset('assets/images/step1.svg'), 
        body: Text(""),
        title: Container(
          padding: EdgeInsets.only(top: 20),
          child: Column(
            children: <Widget>[
              Text(
            "Welcome a GoYogi",
            style: TextStyle(
                fontFamily: "PoppinsRegular", fontSize: 28, color: const Color(0XFFbe1c6f)),
          ),Text(
            "An education for meditation",
            style: TextStyle(
              color: const Color(0xFF473A41),
              fontFamily: "PoppinsRegular",
              fontSize: 18,
            ),
            textAlign: TextAlign.center,
          )
            ],
          )
        ),
        titleTextStyle: TextStyle(fontFamily: 'MyFont', color: const Color(0xFF473A41)),
        bodyTextStyle: TextStyle(fontFamily: 'MyFont', color: const Color(0xFF473A41)),
        mainImage: SvgPicture.asset(
          'assets/images/step1.svg',
          alignment: Alignment.center,
        )), */
    PageViewModel(
        pageColor: Colors.white,
        //bubble: SvgPicture.asset('assets/images/step2.svg'),
        /*body: Container(
          padding: EdgeInsets.only(top: 10, left: 40, right: 40),
          child: Text(
            "A Step to healthy life with GoYogi",
            style: TextStyle(
              color: const Color(0xFF473A41),
              fontFamily: "Montserratel",
              fontSize: 22,
            ),
            textAlign: TextAlign.center,
          ),
        ),*/
        body: Text(""),
        title: Container(
            padding: EdgeInsets.only(top: 20),
            child: Column(
              children: <Widget>[
                Text(
                  "Welcome to GoYogi!",
                  style: TextStyle(
                      fontFamily: "PoppinsRegular",
                      fontSize: 28,
                      color: const Color(0XFFbe1c6f)),
                ),
                Text(
                  "Educate to meditate",
                  style: TextStyle(
                    color: const Color(0xFF473A41),
                    fontFamily: "PoppinsRegular",
                    fontSize: 18,
                  ),
                  textAlign: TextAlign.center,
                )
              ],
            )),
        titleTextStyle:
            TextStyle(fontFamily: 'MyFont', color: const Color(0xFF473A41)),
        bodyTextStyle:
            TextStyle(fontFamily: 'MyFont', color: const Color(0xFF473A41)),
        mainImage: SvgPicture.asset(
          'assets/images/step2.svg',
          alignment: Alignment.center,
        )),
    PageViewModel(
        pageColor: Colors.white,
        //bubble: SvgPicture.asset('assets/images/step3.svg'),
        body: Text(""),
        title: Container(
            padding: EdgeInsets.only(top: 20),
            child: Column(
              children: <Widget>[
                Text(
                  "Learn to live in the ",
                  style: TextStyle(
                      fontFamily: "PoppinsRegular",
                      fontSize: 28,
                      color: const Color(0XFFbe1c6f)),
                ),
                Text(
                  "present moment",
                  style: TextStyle(
                      fontFamily: "PoppinsRegular",
                      fontSize: 28,
                      color: const Color(0XFFbe1c6f)),
                )
                /*Text(
            "An education for meditation",
            style: TextStyle(
              color: const Color(0xFF473A41),
              fontFamily: "PoppinsRegular",
              fontSize: 18,
            ),
            textAlign: TextAlign.center,
          )*/
              ],
            )),
        titleTextStyle:
            TextStyle(fontFamily: 'MyFont', color: const Color(0xFF473A41)),
        bodyTextStyle:
            TextStyle(fontFamily: 'MyFont', color: const Color(0xFF473A41)),
        mainImage: SvgPicture.asset(
          'assets/images/step3.svg',
          alignment: Alignment.center,
        )),
    PageViewModel(
        pageColor: Colors.white,
        // bubble: SvgPicture.asset('assets/images/step4.svg'),
        body: Text(""),
        title: Container(
            padding: EdgeInsets.only(top: 20),
            child: Column(
              children: <Widget>[
                Text(
                  "Prioritize your mental",
                  style: TextStyle(
                      fontFamily: "PoppinsRegular",
                      fontSize: 28,
                      color: const Color(0XFFbe1c6f)),
                ),
                Text(
                  "health",
                  style: TextStyle(
                      fontFamily: "PoppinsRegular",
                      fontSize: 28,
                      color: const Color(0XFFbe1c6f)),
                ), /*Text(
            "An education for meditation",
            style: TextStyle(
              color: const Color(0xFF473A41),
              fontFamily: "PoppinsRegular",
              fontSize: 18,
            ),
            textAlign: TextAlign.center,
          )*/
              ],
            )),
        titleTextStyle:
            TextStyle(fontFamily: 'MyFont', color: const Color(0xFF473A41)),
        bodyTextStyle:
            TextStyle(fontFamily: 'MyFont', color: const Color(0xFF473A41)),
        mainImage: SvgPicture.asset(
          'assets/images/step4.svg',
          alignment: Alignment.center,
        )),
  ];
  @override
  Widget build(BuildContext context) {
    return login_check
        ? Scaffold(
            body: Center(
                child: Container(
                    child: CircularProgressIndicator(
              backgroundColor: Theme.of(context).primaryColor,
            ))),
          )
        : Scaffold(
            //ThemeData
            body: Builder(
              builder: (context) => IntroViewsFlutter(
                pages,
                showNextButton: false,
                showBackButton: false,
                onTapDoneButton: () {
                  Navigator.push(
                    context,
                    MaterialPageRoute(
                      builder: (context) => Loginpage(),
                    ), //MaterialPageRoute
                  );
                },
                pageButtonTextStyles: TextStyle(
                  color: const Color(0xFF473A41),
                  fontSize: 18.0,
                ),
              ), //IntroViewsFlutter
            ), //Builder
          ); //Material App
  }
}
