import 'package:flutter/material.dart';
import './pages/start/start.dart';

void main() => runApp(MyApp());

class MyApp extends StatelessWidget {
  

  @override
  Widget build(BuildContext context) {
    
    return MaterialApp(debugShowCheckedModeBanner: false,
     theme: new ThemeData(
        primaryColor: Color(0XFFbe1c6f),
        primaryColorDark: Colors.white,
        accentColor: Colors.white,
       
      ),
      home:StartPage()
    );
  }
}
